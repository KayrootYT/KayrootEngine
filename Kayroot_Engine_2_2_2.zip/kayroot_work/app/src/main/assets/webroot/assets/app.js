/* Kayroot Engine UI v3 - talks to the Android backend through window.KayrootApp */
(function () {
'use strict';
const $ = (s, r = document) => r.querySelector(s);
const $$ = (s, r = document) => [...r.querySelectorAll(s)];
const store = {
  get: (k, d) => { try { const v = localStorage.getItem('kr_' + k); return v === null ? d : JSON.parse(v); } catch (e) { return d; } },
  set: (k, v) => { try { localStorage.setItem('kr_' + k, JSON.stringify(v)); } catch (e) {} }
};

/* ---------------------------------------------------------------- bridge (+ browser mock for previews) */
const hasNative = !!window.KayrootApp;
if (!hasNative) installMock();
let cbN = 0;
function call(action, args) {
  return new Promise(resolve => {
    const cb = 'kcb' + (++cbN);
    const t = setTimeout(() => { delete window[cb]; resolve({ ok: false, msg: 'Timeout' }); }, 120000);
    window[cb] = r => { clearTimeout(t); delete window[cb]; resolve(r); };
    try { KayrootApp.call(action, JSON.stringify(args || {}), cb); }
    catch (e) { clearTimeout(t); resolve({ ok: false, msg: String(e) }); }
  });
}
function callFast(action, args) {
  return new Promise(resolve => {
    const cb = 'kfb' + (++cbN);
    const t = setTimeout(() => { delete window[cb]; resolve({ ok: false, msg: 'Timeout' }); }, 20000);
    window[cb] = r => { clearTimeout(t); delete window[cb]; resolve(r); };
    try { KayrootApp.fastCall(action, JSON.stringify(args || {}), cb); }
    catch (e) { clearTimeout(t); resolve({ ok: false, msg: String(e) }); }
  });
}
const native = (fn, ...a) => { try { return KayrootApp[fn](...a); } catch (e) { return null; } };
const haptic = () => { if (store.get('haptic', true)) native('haptic'); };

/* ---------------------------------------------------------------- helpers */
const esc = x => String(x).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const fmtAgo = t => { if (!t) return 'never'; const m = Math.round((Date.now() - t) / 60000); return m < 1 ? 'just now' : m < 60 ? m + ' min ago' : m < 1440 ? Math.round(m / 60) + ' h ago' : Math.round(m / 1440) + ' d ago'; };
const na = (v, f) => (v === null || v === undefined) ? null : f(v);
const tint = (hex, a) => { const n = parseInt(hex.slice(1), 16); return 'rgba(' + (n >> 16) + ',' + ((n >> 8) & 255) + ',' + (n & 255) + ',' + a + ')'; };
const light = hex => { const n = parseInt(hex.slice(1), 16); const m = v => Math.round(v + (255 - v) * .3); return 'rgb(' + m(n >> 16) + ',' + m((n >> 8) & 255) + ',' + m(n & 255) + ')'; };
function paint(el, c) { el.style.setProperty('--c', c); el.style.setProperty('--c40', tint(c, .4)); el.style.setProperty('--c14', tint(c, .14)); el.style.setProperty('--cl', light(c)); }
$$('[data-c]').forEach(e => paint(e, e.dataset.c));
const KV = rows => rows.map(r => '<div><span>' + r[0] + '</span>' + (r[1] === null || r[1] === undefined ? '<b class="na">N/A</b>' : '<b class="' + (r[2] || '') + '">' + esc(r[1]) + '</b>') + '</div>').join('');
function tween(el, to, fmt) {
  const from = parseFloat(el.dataset.v) || 0; el.dataset.v = to; const t0 = performance.now();
  (function f(t) { const k = Math.min(1, (t - t0) / 650), e = 1 - Math.pow(1 - k, 3); el.textContent = fmt(from + (to - from) * e); if (k < 1) requestAnimationFrame(f); })(t0);
}

/* ripple on every tappable surface */
document.addEventListener('pointerdown', e => {
  const t = e.target.closest && e.target.closest('.fc.tap,.pc,.btn,.mini-btn,.chip,.acc-h'); if (!t) return;
  const r = t.getBoundingClientRect(), s = Math.max(r.width, r.height) * 2;
  const d = document.createElement('span'); d.className = 'rip';
  d.style.cssText = 'width:' + s + 'px;height:' + s + 'px;left:' + (e.clientX - r.left - s / 2) + 'px;top:' + (e.clientY - r.top - s / 2) + 'px';
  t.appendChild(d); setTimeout(() => d.remove(), 650);
}, { passive: true });

/* ---------------------------------------------------------------- toast + logs */
function toast(msg, type) {
  type = type || 'info';
  const el = document.createElement('div');
  el.className = 'toast ' + type;
  const ic = type === 'success' ? 'fa-circle-check' : type === 'error' ? 'fa-circle-exclamation' : 'fa-circle-info';
  el.innerHTML = '<i class="fas ' + ic + '"></i><span></span>';
  el.lastChild.textContent = msg;
  $('#toasts').appendChild(el);
  setTimeout(() => { el.classList.add('out'); setTimeout(() => el.remove(), 300); }, 3000);
}
window.toast = toast;   // the Android side calls toast() directly
const clock = () => new Date().toLocaleTimeString();

const OPIC = [[/clean/i, 'fa-broom', '#a855f7'], [/cool|thermal|temp/i, 'fa-fan', '#29b6f6'], [/optim|dexopt|recompile|trim|maintenance/i, 'fa-rocket', '#2ed573'],
  [/net/i, 'fa-tower-broadcast', '#ffa502'], [/profile|game|power|multi|auto|reset/i, 'fa-sliders', '#00f5d4'], [/overlay/i, 'fa-window-restore', '#ff4dd2'],
  [/mode|access|shizuku|root/i, 'fa-shield-halved', '#9d4edd'], [/disable|enable|app/i, 'fa-box', '#f5c518']];
function tlItem(e) {
  let ic = 'fa-check', c = '#2ed573';
  if (!e.ok) { ic = 'fa-xmark'; c = '#ff6b81'; } else { for (const o of OPIC) if (o[0].test(e.m)) { ic = o[1]; c = o[2]; break; } }
  const d = document.createElement('div'); d.className = 'tl-item'; paint(d, c);
  d.innerHTML = '<div class="dot"><i class="fas ' + ic + '"></i></div><div class="tx"><b></b><small></small></div>' + (e.ok ? '' : '<span class="st">FAILED</span>');
  $('b', d).textContent = e.m; $('small', d).textContent = fmtAgo(e.t);
  return d;
}
const emptyLog = txt => '<div class="empty-log"><i class="fa-regular fa-clock"></i>' + txt + '</div>';
function log(msg, type) {
  const list = $('#log-list'); const empty = $('.empty-log', list); if (empty) empty.remove();
  list.prepend(tlItem({ m: msg, ok: (type || 'success') !== 'error', t: Date.now() }));
  while (list.children.length > 50) list.lastChild.remove();
}
function term(msg, type) {
  const t = $('#term');
  const d = $('.term-line.dim', t); if (d) d.remove();
  const l = document.createElement('div');
  l.className = 'term-line ' + (type || '');
  l.innerHTML = '<span>&gt;</span><i class="fas ' + (type === 'error' ? 'fa-circle-xmark' : 'fa-circle-check') + '"></i><span></span>';
  l.lastChild.textContent = clock() + ': ' + msg;
  t.appendChild(l); t.scrollTop = t.scrollHeight;
  while (t.children.length > 40) t.firstChild.remove();
}
const report = (ok, msg) => { toast(msg, ok ? 'success' : 'error'); setTimeout(loadLog, 400); };

/* ---------------------------------------------------------------- navigation */
const PAGES = ['home', 'apps', 'quick', 'adv', 'settings'];
let page = 'home';
function stagger() { $$('#page-' + page + ' > *').forEach((e, i) => e.style.setProperty('--i', i)); }
function placeIndicator() {
  const b = $('#bnav button.active'), i = $('#nav-ind'); if (!b) return;
  i.style.width = b.offsetWidth + 'px'; i.style.transform = 'translateX(' + b.offsetLeft + 'px)';
}
function go(p) {
  if (p === page) return;
  page = p;
  $$('.page').forEach(x => x.classList.toggle('active', x.id === 'page-' + p));
  $$('#bnav button').forEach(b => b.classList.toggle('active', b.dataset.page === p));
  stagger(); placeIndicator();
  window.scrollTo({ top: 0, behavior: 'smooth' });
  haptic();
  if (p === 'adv') { refreshToggles(); refreshGov(); refreshBattery(); refreshOverlay(); }
  if (p === 'quick') { loadLog(); refreshExtra(); refreshCooldown(); }
  if (p === 'apps') loadApps(false);
  if (p === 'settings') refreshPerms();
  if (p === 'home') loadLog();
  if (p !== 'adv' && monTimer) stopMonitor();
}
$$('#bnav button').forEach(b => b.addEventListener('click', () => go(b.dataset.page)));
window.addEventListener('resize', placeIndicator);

/* back button: close sheet/dialog first, then go Home, then let Android exit */
window.kayrootBack = function () {
  const m = $('#modal');
  if (m.classList.contains('show')) { $('#modal-no').hidden ? $('#modal-ok').click() : $('#modal-no').click(); return true; }
  const sh = $$('.overlay.sheet.show'); if (sh.length) { sh.forEach(x => x.classList.remove('show')); return true; }
  if (page !== 'home') { go('home'); return true; }
  return false;
};

/* ---------------------------------------------------------------- state */
let status = { mode: 'basic' };
const rank = () => status.mode === 'root' ? 2 : status.mode === 'shizuku' ? 1 : 0;

function applyStatus(s) {
  status = s || status;
  $$('#mode-seg button').forEach(b => b.classList.toggle('active', b.dataset.mode === status.mode));
  let h;
  if (status.mode === 'basic') {
    if (!status.shizukuInstalled) h = 'Basic mode: only <b>Cleaner</b> &amp; <b>Cooling</b> work. Install <b>Shizuku</b> for profiles, Optimizer &amp; system controls (no root needed).';
    else if (!status.shizukuRunning) h = 'Shizuku is installed but <b>not running</b>. Start it (Wireless debugging), then tap <b>Shizuku</b>.';
    else h = 'Tap <b>Shizuku</b> and allow permission to unlock Pro features.';
  } else if (status.mode === 'shizuku') {
    h = status.shizukuGranted ? 'Shizuku active: profiles, deep cleaner, optimizer &amp; system controls enabled.'
                              : 'Shizuku mode selected but the service is <b>not running</b>. Start Shizuku again.';
  } else h = 'Root active: CPU governors, bypass charging, I/O &amp; kernel tweaks unlocked.';
  $('#access-hint').innerHTML = h;
  $('#device-line').textContent = (status.device || '') + ' | ' + (status.soc || '?') + ' | API ' + (status.sdk || '?');
  setProfileUI(status.profile || '', status.ai);
  lockToggles();
  $('#set-boot').checked = !!status.boot;
  const dbg = $('#set-debug'); if (dbg) dbg.checked = !!status.debug;
}
window.onKayrootStatus = applyStatus;

$$('#mode-seg button').forEach(b => b.addEventListener('click', () => {
  haptic(); log('Switching access mode: ' + b.dataset.mode, 'info');
  native('selectMode', b.dataset.mode);
}));
$('#open-shizuku').addEventListener('click', () => native('openShizuku'));
$('#recent-all').addEventListener('click', () => go('quick'));

/* ---------------------------------------------------------------- profiles */
const PROFILES = [
  { id: 'auto', name: 'Auto AI Mode', desc: 'Adaptive rules engine: reacts to heat, battery & app', icon: 'fa-robot', c: '#f5c518' },
  { id: 'game', name: 'Game Booster', desc: 'Performance mode. More heat and battery use', icon: 'fa-gamepad', c: '#ff3b3b' },
  { id: 'daytoday', name: 'Multitasking', desc: 'Balanced for everyday multitasking', icon: 'fa-list-check', c: '#29b6f6' },
  { id: 'powersave', name: 'Power Saving', desc: 'Power Save: longer battery, slower animations', icon: 'fa-battery-half', c: '#2ed573' }
];
const pl = $('#profile-list');
PROFILES.forEach((p, j) => {
  const d = document.createElement('div');
  d.className = 'pc tap'; d.dataset.id = p.id; d.dataset.desc = p.desc; paint(d, p.c); d.style.setProperty('--j', j);
  d.innerHTML = '<div class="fi"><i class="fas ' + p.icon + '"></i></div><div class="ft"><b>' + p.name + '</b><small>' + p.desc + '</small></div><div class="sel">SELECT</div>';
  d.addEventListener('click', () => selectProfile(p.id));
  pl.appendChild(d);
});
function setProfileUI(id, ai) {
  $$('.pc').forEach(c => {
    const on = c.dataset.id === id; c.classList.toggle('on', on); $('.sel', c).textContent = on ? 'APPLIED' : 'SELECT';
    $('small', c).textContent = (c.dataset.id === 'auto' && on && ai && ai.on && ai.reason) ? 'Running: ' + ai.reason : c.dataset.desc;
  });
  const p = PROFILES.find(x => x.id === id);
  let name = p ? p.name : 'Not selected';
  if (id === 'auto' && ai && ai.profile) name += ' (' + ({ game: 'Game', daytoday: 'Multitasking', powersave: 'Power Saving' }[ai.profile] || ai.profile) + ')';
  $('#cur-profile').textContent = name;
}
async function selectProfile(id) {
  const card = $('.pc[data-id="' + id + '"]');
  if (card.classList.contains('busy')) return;
  haptic(); card.classList.add('busy');
  const r = await call('profile', { name: id });
  card.classList.remove('busy');
  const nm = PROFILES.find(x => x.id === id).name;
  if (r.ok) { setProfileUI(id, null); report(true, nm + ' applied'); }
  else report(false, r.msg || 'Failed');
  refreshStatus();
}
$('#reset-btn').addEventListener('click', async () => {
  haptic(); const r = await call('reset');
  if (r.ok) { setProfileUI('', null); report(true, 'Profiles reset'); } else report(false, r.msg || 'Reset failed');
  refreshStatus();
});

/* ---------------------------------------------------------------- quick page: tiles */
function tile(grid, o) {
  const b = document.createElement('div');
  b.className = 'fc tap'; b.setAttribute('role', 'button'); paint(b, o.c); b.style.setProperty('--j', grid.children.length);
  if (o.id) b.id = o.id;
  b.dataset.def = o.sub;
  b.innerHTML = '<div class="fi"><i class="fas ' + o.icon + '"></i></div><div class="ft"><b>' + o.name + '</b><small class="qs">' + o.sub + '</small></div>' +
    '<div class="fx">' + (o.tag ? '<span class="pill warn">' + o.tag + '</span>' : '') + '<i class="fa-solid fa-chevron-right dim"></i></div>';
  b.addEventListener('click', () => o.run(b));
  grid.appendChild(b); return b;
}
const QUICK = [
  { id: 'clean', name: 'Cleaner', sub: 'Free RAM, trim caches', icon: 'fa-broom', c: '#a855f7', ok: 'Cleaner finished' },
  { id: 'cool', name: 'Cooling', sub: 'Close heavy apps, cool down', icon: 'fa-fan', c: '#29b6f6', ok: 'Cooling finished' },
  { id: 'optimize', name: 'Optimizer', sub: 'Tune the system for speed', icon: 'fa-rocket', c: '#2ed573', ok: 'Optimizer started' },
  { id: 'netrefresh', name: 'Net Refresh', sub: 'Reset network connection', icon: 'fa-tower-broadcast', c: '#ffa502', ok: 'Network refreshed' }
];
QUICK.forEach(q => tile($('#quick-grid'), { name: q.name, sub: q.sub, icon: q.icon, c: q.c, run: async b => {
  haptic(); b.classList.add('busy');
  const r = await call(q.id);
  b.classList.remove('busy');
  report(r.ok, r.ok ? (r.msg || q.ok) : (r.msg || 'Failed'));
} }));
$('#clear-log').addEventListener('click', async () => { haptic(); await call('log_clear'); loadLog(); });

/* ---------------------------------------------------------------- system controls (Advance) */
const TOGGLES = [
  { key: 'dnd', c: '#a855f7', icon: 'fa-bell-slash', title: 'Do Not Disturb', on: 'DND is active', off: 'DND is inactive', ic: ['fa-bell-slash', 'fa-bell'], need: 1 },
  { key: 'bypass', c: '#ffa502', icon: 'fa-bolt', title: 'Bypass Charging', on: 'Bypass is active', off: 'Bypass is inactive', ic: ['fa-bolt', 'fa-bolt'], need: 2 },
  { key: 'battery_saver', c: '#2ed573', icon: 'fa-battery-quarter', title: 'Battery Saver', on: 'Battery saver is on', off: 'Battery saver is off', ic: ['fa-leaf', 'fa-leaf'], need: 1 },
  { key: 'hi_refresh', c: '#29b6f6', icon: 'fa-gauge-high', title: 'Max Refresh Rate', on: 'Max refresh locked', off: 'Refresh rate is auto', ic: ['fa-display', 'fa-display'], need: 1 },
  { key: 'fast_anim', c: '#ff4dd2', icon: 'fa-wand-magic-sparkles', title: 'Fast Animations', on: 'Animations 0.5x', off: 'Animations 1x', ic: ['fa-forward-fast', 'fa-forward'], need: 1 },
  { key: 'stay_awake', c: '#f5c518', icon: 'fa-plug-circle-bolt', title: 'Stay Awake (Charging)', on: 'Screen stays on', off: 'Normal screen timeout', ic: ['fa-sun', 'fa-moon'], need: 1 }
];
let tState = {};
const tl = $('#toggle-list');
TOGGLES.forEach((t, j) => {
  const d = document.createElement('div');
  d.className = 'fc'; d.id = 'sys-' + t.key; paint(d, t.c); d.style.setProperty('--j', j);
  d.innerHTML = '<div class="fi"><i class="fas ' + t.icon + '"></i></div><div class="ft"><b>' + t.title + (t.need === 2 ? ' <span class="pill root">ROOT</span>' : '') + '</b><small>--</small></div><label class="switch"><input type="checkbox"><span></span></label>';
  tl.appendChild(d);
  const inp = $('input', d);
  inp.addEventListener('change', async () => {
    const want = inp.checked;
    if (rank() < t.need) { inp.checked = !want; toast(t.need === 2 ? 'Root required for this control' : 'Enable Shizuku or Root first (HOME \u2192 Access Mode)', 'error'); return; }
    haptic(); inp.disabled = true;
    const r = await call('toggle_set', { key: t.key, on: want });
    inp.disabled = false;
    const label = t.title.split(' (')[0].toUpperCase();
    term(r.ok ? label + (want ? ' enabled' : ' disabled') : label + ' failed: ' + (r.msg || 'error'), r.ok ? '' : 'error');
    if (!r.ok) toast(r.msg || 'Failed', 'error');
    refreshToggles();
  });
});
function renderToggle(t) {
  const d = $('#sys-' + t.key); if (!d) return;
  const st = tState[t.key]; const on = !!(st && st.on); const sup = !st || st.supported !== false;
  const locked = rank() < t.need;
  d.classList.toggle('on', on && sup); d.classList.toggle('locked', locked);
  $('.fi i', d).className = 'fas ' + t.ic[on ? 0 : 1];
  $('small', d).textContent = !sup ? 'Not supported on this device' : locked ? (t.need === 2 ? 'Needs Root access' : 'Needs Shizuku or Root') : (on ? t.on : t.off);
  const inp = $('input', d); inp.checked = on; inp.disabled = !sup;
}
const lockToggles = () => TOGGLES.forEach(renderToggle);
async function refreshToggles() {
  const r = await callFast('toggle_get_all');
  if (r && r.data) { tState = r.data; lockToggles(); }
}
setInterval(() => { if (!document.hidden && page === 'adv') refreshToggles(); }, 6000);

async function refreshGov() {
  const hint = $('#gov-hint'), chips = $('#gov-chips');
  if (rank() < 2) { hint.textContent = 'Needs Root access'; chips.innerHTML = ''; return; }
  const r = await call('gov_info');
  if (!r.ok || !r.data) { hint.textContent = r.msg || 'Governor info unavailable'; chips.innerHTML = ''; return; }
  hint.textContent = 'Current: ' + r.data.current;
  chips.innerHTML = '';
  (r.data.available || []).forEach(g => {
    const c = document.createElement('button');
    c.className = 'chip' + (g === r.data.current ? ' on' : ''); c.textContent = g;
    c.addEventListener('click', async () => {
      haptic(); const x = await call('gov_set', { name: g });
      term(x.ok ? 'GOVERNOR set to ' + g : 'GOVERNOR failed: ' + (x.msg || 'error'), x.ok ? '' : 'error');
      refreshGov();
    });
    chips.appendChild(c);
  });
}

/* ---------------------------------------------------------------- settings */
const THEMES = [['#00f5d4', '#9d4edd', 'CYBER'], ['#ff4dd2', '#7b2cff', 'NEON'], ['#39ff14', '#00b4d8', 'MATRIX'], ['#ffb300', '#ff3b3b', 'SOLAR']];
const th = $('#themes');
function applyTheme(i) {
  const t = THEMES[i] || THEMES[0];
  document.documentElement.style.setProperty('--accent', t[0]);
  document.documentElement.style.setProperty('--accent2', t[1]);
  $$('.tdot').forEach((d, k) => d.classList.toggle('on', k === i));
}
THEMES.forEach((t, i) => {
  const d = document.createElement('button'); d.className = 'tdot'; d.textContent = t[2];
  d.style.setProperty('--tc', t[0]); d.style.setProperty('--tc2', t[1]);
  d.addEventListener('click', () => { store.set('theme', i); applyTheme(i); haptic(); });
  th.appendChild(d);
});
applyTheme(store.get('theme', 0));
$('#set-rain').checked = store.get('rain', true);
$('#set-haptic').checked = store.get('haptic', true);
$('#set-rain').addEventListener('change', e => { store.set('rain', e.target.checked); rainOn = e.target.checked; $('#rain').style.display = rainOn ? '' : 'none'; });
$('#set-haptic').addEventListener('change', e => store.set('haptic', e.target.checked));
$('#set-boot').addEventListener('change', async e => {
  const r = await call('boot_set', { on: e.target.checked });
  if (!r.ok) { e.target.checked = !e.target.checked; toast(r.msg || 'Failed', 'error'); }
});

function modal(title, html, okText, cancelText) {
  return new Promise(res => {
    const m = $('#modal'), ok = $('#modal-ok'), no = $('#modal-no');
    $('#modal-title').textContent = title; $('#modal-body').innerHTML = html;
    ok.textContent = okText || 'OK'; no.textContent = cancelText || 'Cancel'; no.hidden = cancelText === null;
    const done = v => { m.classList.remove('show'); ok.onclick = no.onclick = null; res(v); };
    ok.onclick = () => done(true); no.onclick = () => done(false);
    m.classList.add('show');
  });
}

/* ---------- history (persisted natively) ---------- */
async function loadLog() {
  const r = await callFast('log_get'); if (!r.ok || !r.data) return;
  const list = $('#log-list'); list.innerHTML = '';
  if (!r.data.length) list.innerHTML = emptyLog('No activity yet');
  r.data.forEach(e => list.appendChild(tlItem(e)));
  const hr = $('#home-recent');
  hr.innerHTML = r.data.length ? '' : emptyLog('No operations yet');
  r.data.slice(0, 4).forEach(e => hr.appendChild(tlItem(e)));
  $('#recent-sub').textContent = r.data.length ? r.data.length + ' operations logged' : 'Latest actions on this device';
}
$('#hist-clear').addEventListener('click', async () => { haptic(); await call('log_clear'); loadLog(); toast('History cleared', 'success'); });
$('#set-debug').addEventListener('change', e => call('debug_set', { on: e.target.checked }));

/* ---------------------------------------------------------------- monitor page */
$$('.acc').forEach(a => {
  paint(a, a.dataset.c);
  $('.acc-h', a).addEventListener('click', () => { a.classList.toggle('open'); haptic(); if (a.id === 'acc-bat' && a.classList.contains('open')) refreshBattery(); });
});
$('#mon-cpu').innerHTML = KV([['CPU usage', '--'], ['Cores / max clock', '--'], ['GPU usage', '--'], ['GPU clock', '--']]);
$('#mon-mem').innerHTML = KV([['RAM used', '--'], ['Memory pressure', '--'], ['Cached', '--'], ['Swap used', '--']]);
$('#mon-thm').innerHTML = KV([['CPU temp', '--'], ['Battery temp', '--'], ['Thermal status', '--']]);

let monTimer = null, monInt = 2000; const hist = [];
const MON_INTS = [[1000, '1s'], [2000, '2s'], [5000, '5s']];
MON_INTS.forEach(([v, t]) => { const c = document.createElement('button'); c.className = 'chip' + (v === monInt ? ' on' : ''); c.textContent = t; c.dataset.v = v;
  c.addEventListener('click', () => { monInt = v; $$('#mon-int .chip').forEach(x => x.classList.toggle('on', +x.dataset.v === v)); if (monTimer) { stopMonitor(); startMonitor(); } haptic(); }); $('#mon-int').appendChild(c); });

function setBig(pct) {
  const el = $('#mon-ring'), b = $('.bv b', el), fg = $('.fg', el);
  if (pct === null) { fg.style.strokeDashoffset = 314; el.style.setProperty('--rc', 'rgba(220,240,255,.45)'); b.dataset.v = 0; b.textContent = 'N/A'; return; }
  fg.style.strokeDashoffset = 314 * (1 - Math.max(0, Math.min(100, pct)) / 100);
  el.style.setProperty('--rc', pct > 85 ? '#ff4d6d' : pct > 60 ? '#ffa502' : getComputedStyle(document.documentElement).getPropertyValue('--accent').trim() || '#00f5d4');
  tween(b, pct, v => v.toFixed(0) + '%');
}
function drawGraph() {
  const c = $('#cpu-graph'); const w = c.clientWidth; if (!w) return; const dpr = window.devicePixelRatio || 1, H = 70;
  c.width = w * dpr; c.height = H * dpr; const x = c.getContext('2d'); x.scale(dpr, dpr);
  x.strokeStyle = 'rgba(255,255,255,.07)'; x.beginPath(); [18, 35, 52].forEach(y => { x.moveTo(0, y); x.lineTo(w, y); }); x.stroke();
  const pts = hist.filter(h => h !== null);
  if (pts.length < 2) { x.fillStyle = 'rgba(220,245,255,.5)'; x.font = '11px system-ui'; x.fillText(hist.length && pts.length === 0 ? 'CPU graph: N/A on this access level' : hist.length ? 'collecting samples...' : 'Press Start for a live graph', 12, 40); return; }
  const col = getComputedStyle(document.documentElement).getPropertyValue('--accent').trim() || '#0f8';
  const step = w / 59, off = (60 - hist.length) * step;
  const y = v => H - 4 - (v === null ? 0 : v) * (H - 10) / 100;
  x.beginPath(); hist.forEach((v, i) => { const px = off + i * step, py = y(v); i ? x.lineTo(px, py) : x.moveTo(px, py); });
  x.strokeStyle = col; x.lineWidth = 2; x.lineJoin = 'round'; x.stroke();
  x.lineTo(off + (hist.length - 1) * step, H); x.lineTo(off, H); x.closePath();
  const g = x.createLinearGradient(0, 0, 0, H); g.addColorStop(0, col + '55'); g.addColorStop(1, col + '00'); x.fillStyle = g; x.fill();
}
let monBusy = false;
async function monTick() {
  if (monBusy || document.hidden) return; monBusy = true;
  const r = await callFast('mon_sample'); monBusy = false;
  if (!r.ok || !r.data) return; const d = r.data, b = d.battery, m = d.ram;
  hist.push(d.cpuPct === null ? null : d.cpuPct); if (hist.length > 60) hist.shift();
  const mx = d.freqMhz && d.freqMhz.length ? Math.max.apply(null, d.freqMhz) : null;
  setBig(d.cpuPct);
  $('#mon-cores').textContent = d.cores + ' / ' + (mx ? mx + ' MHz' : 'N/A');
  $('#mon-therm').textContent = d.thermal === 'N/A' ? 'N/A' : d.thermal;
  $('#mon-ram').textContent = m.usedMb + ' / ' + m.totalMb + ' MB';
  $('#mon-cpu').innerHTML = KV([['CPU usage', na(d.cpuPct, v => v.toFixed(0) + '%')], ['Cores / max clock', d.cores + (mx ? ' / ' + mx + ' MHz' : ' / N/A')], ['GPU usage', na(d.gpuPct, v => v.toFixed(0) + '%')], ['GPU clock', na(d.gpuMhz, v => v.toFixed(0) + ' MHz')]]);
  $('#mon-mem').innerHTML = KV([['RAM used', m.usedMb + ' / ' + m.totalMb + ' MB'], ['Memory pressure', m.pressure], ['Cached', m.cachedMb == null ? null : m.cachedMb + ' MB'], ['Swap used', m.swapTotalMb == null ? null : (m.swapTotalMb - m.swapFreeMb) + ' MB']]);
  $('#mon-thm').innerHTML = KV([['CPU temp', na(d.cpuTemp, v => v.toFixed(1) + '\u00b0C')], ['Battery temp', na(b.tempC, v => v.toFixed(1) + '\u00b0C')], ['Thermal status', d.thermal === 'N/A' ? null : d.thermal]]);
  $('#acc-cpu .fs').textContent = 'CPU ' + (d.cpuPct === null ? 'N/A' : d.cpuPct.toFixed(0) + '%') + ' \u2022 GPU ' + (d.gpuPct === null ? 'N/A' : d.gpuPct.toFixed(0) + '%');
  $('#acc-mem .fs').textContent = (m.usedMb / 1024).toFixed(1) + ' / ' + (m.totalMb / 1024).toFixed(1) + ' GB \u2022 ' + m.pressure;
  $('#acc-thm .fs').textContent = (b.tempC == null ? 'N/A' : b.tempC.toFixed(1) + '\u00b0C') + ' \u2022 ' + (d.thermal === 'N/A' ? 'status N/A' : d.thermal);
  $('#mon-note').textContent = d.cpuPct === null && d.mode === 'basic' ? 'CPU/GPU usage needs Shizuku or Root: Android blocks it for normal apps.' : 'Sampling every ' + (monInt / 1000) + ' s. FPS is in the overlay below.';
  drawGraph();
}
function startMonitor() { monTick(); monTimer = setInterval(monTick, monInt); $('#mon-toggle').innerHTML = '<i class="fa-solid fa-stop"></i> Stop'; }
function stopMonitor() { clearInterval(monTimer); monTimer = null; const t = $('#mon-toggle'); if (t) t.innerHTML = '<i class="fa-solid fa-play"></i> Start'; }
$('#mon-toggle').addEventListener('click', () => { haptic(); if (monTimer) stopMonitor(); else { hist.length = 0; call('mon_reset'); startMonitor(); } });
document.addEventListener('visibilitychange', () => { if (document.hidden && monTimer) stopMonitor(); });
setTimeout(drawGraph, 300);

/* ---------- battery ---------- */
async function refreshBattery() {
  const r = await callFast('batt_info'); if (!r.ok || !r.data) return; const b = r.data;
  $('#bat-grid').innerHTML = KV([['Level', b.level + '%'], ['State', b.status + (b.plugged !== 'No' ? ' (' + b.plugged + ')' : '')], ['Voltage', (b.voltageMv / 1000).toFixed(2) + ' V'], ['Temperature', na(b.tempC, v => v.toFixed(1) + '\u00b0C')],
    ['Current (approx.)', na(b.currentMa, v => v.toFixed(0) + ' mA')], ['Power (approx.)', na(b.powerW, v => v.toFixed(1) + ' W')], ['Health (Android)', b.health],
    ['Capacity (estimate)', na(b.estFullMah, v => '~' + v.toFixed(0) + ' mAh')], ['Charge now', na(b.chargeNowMah, v => v.toFixed(0) + ' mAh')], ['Cycles', na(b.cycles, v => String(v))]]);
  $('#acc-bat .fs').textContent = b.level + '% \u2022 ' + b.status + (b.powerW != null ? ' \u2022 ' + Math.abs(b.powerW).toFixed(1) + ' W' : '');
  $('#bat-opt-txt').textContent = b.battOptIgnored ? 'Battery use: unrestricted (tap to review)' : 'Battery use: optimized (tap to allow background)';
}
$('#bat-opt').addEventListener('click', () => native('openSystem', 'battery'));

/* ---------- overlay ---------- */
const OV = [['fps', 'FPS'], ['cpu', 'CPU'], ['gpu', 'GPU'], ['ram', 'RAM'], ['bat', 'Battery'], ['temp', 'Temp'], ['pwr', 'Power']];
let ovCfg = { stats: 'fps,cpu,ram,bat,temp', running: false };
OV.forEach(([k, t]) => { const c = document.createElement('button'); c.className = 'chip'; c.textContent = t; c.dataset.k = k;
  c.addEventListener('click', () => { const set = new Set(ovCfg.stats.split(',').filter(Boolean)); set.has(k) ? set.delete(k) : set.add(k); ovCfg.stats = [...set].join(','); paintOv(); call('overlay_cfg_set', { stats: ovCfg.stats }); haptic(); }); $('#ov-stats').appendChild(c); });
function paintOv() {
  const on = new Set(ovCfg.stats.split(',').filter(Boolean)); $$('#ov-stats .chip').forEach(c => c.classList.toggle('on', on.has(c.dataset.k)));
  $('#ov-toggle').innerHTML = ovCfg.running ? '<i class="fa-solid fa-stop"></i> Stop overlay' : '<i class="fa-solid fa-play"></i> Start overlay';
  $('#ov-alpha-v').textContent = $('#ov-alpha').value + '%'; $('#ov-size-v').textContent = $('#ov-size').value + ' sp'; $('#ov-int-v').textContent = ($('#ov-int').value / 1000).toFixed(2) + ' s';
  $('#acc-ov .fs').textContent = ovCfg.running ? 'Running \u2022 ' + on.size + ' stats shown' : 'Off \u2022 tap to configure';
  $('#acc-ov').classList.toggle('on', !!ovCfg.running);
}
async function refreshOverlay() {
  const r = await callFast('overlay_cfg_get'); if (!r.ok || !r.data) return; ovCfg = r.data;
  $('#ov-alpha').value = ovCfg.alpha; $('#ov-size').value = ovCfg.size; $('#ov-int').value = ovCfg.interval; paintOv();
}
[['#ov-alpha', 'alpha'], ['#ov-size', 'size'], ['#ov-int', 'interval']].forEach(([sel, key]) => { const el = $(sel); el.addEventListener('input', paintOv); el.addEventListener('change', () => call('overlay_cfg_set', { [key]: +el.value })); });
$('#ov-toggle').addEventListener('click', async () => {
  haptic();
  if (ovCfg.running) { const r = await call('overlay_stop'); report(r.ok, r.msg || 'Stopped'); }
  else {
    const r = await call('overlay_start');
    if (r.perm) { const g = await modal('Permission needed', 'The overlay draws on top of other apps, so Android asks you to allow <b>Display over other apps</b> for Kayroot. Nothing else is accessed.', 'Open settings'); if (g) native('openSystem', 'overlay'); }
    else report(r.ok, r.msg || 'Failed');
  }
  setTimeout(refreshOverlay, 600);
});

/* ---------------------------------------------------------------- apps (with real icons) */
const iconCache = new Map(), iconWant = new Set(); let iconBusy = false, iconTimer = null;
const hash = s => { let h = 0; for (let i = 0; i < s.length; i++) h = (h * 31 + s.charCodeAt(i)) >>> 0; return h; };
function attachImg(d, src) { const im = new Image(); im.alt = ''; im.onload = () => im.classList.add('ld'); im.src = src; d.appendChild(im); }
function fillAvatar(d, name, pkg) {
  const hue = hash(pkg) % 360;
  d.dataset.p = pkg; d.style.setProperty('--c', 'hsl(' + hue + ',72%,64%)'); d.style.setProperty('--c2', 'hsl(' + ((hue + 55) % 360) + ',72%,46%)');
  d.textContent = (name || '?').trim().charAt(0).toUpperCase();
  const c = iconCache.get(pkg); if (c) attachImg(d, c);
}
const iconTry = new Map();
async function flushIcons() {
  if (iconBusy) { iconTimer = setTimeout(flushIcons, 120); return; }
  const batch = [...iconWant].slice(0, 12); if (!batch.length) return; batch.forEach(p => iconWant.delete(p));
  iconBusy = true; const r = await callFast('app_icons', { pkgs: batch }); iconBusy = false;
  if (!r || !r.ok) {   // bridge busy/timeout: retry a few times instead of caching "no icon" forever
    batch.forEach(p => { const n = (iconTry.get(p) || 0) + 1; iconTry.set(p, n); if (n < 4) iconWant.add(p); else iconCache.set(p, ''); });
    if (iconWant.size) iconTimer = setTimeout(flushIcons, 1500); return;
  }
  const got = r.data || {};
  batch.forEach(p => { iconCache.set(p, got[p] || ''); if (got[p]) $$('.ai[data-p="' + p + '"]').forEach(el => { if (!$('img', el)) attachImg(el, got[p]); }); });
  if (iconWant.size) iconTimer = setTimeout(flushIcons, 30);
}
function wantIcon(p) { if (iconCache.has(p)) return; iconWant.add(p); clearTimeout(iconTimer); iconTimer = setTimeout(flushIcons, 40); }
const io = 'IntersectionObserver' in window ? new IntersectionObserver(es => es.forEach(e => { if (e.isIntersecting) { io.unobserve(e.target); wantIcon(e.target.dataset.p); } }), { rootMargin: '400px' }) : null;
function avatar(name, pkg) { const d = document.createElement('div'); d.className = 'ai'; fillAvatar(d, name, pkg); if (io) io.observe(d); else wantIcon(pkg); return d; }

let appsAll = [], appsLoaded = false, appFilter = 'user', excl = new Set();
const AFILTERS = [['user', 'User'], ['system', 'System'], ['disabled', 'Disabled'], ['all', 'All'], ['excl', 'Excluded']];
AFILTERS.forEach(([k, t]) => { const c = document.createElement('button'); c.className = 'chip' + (k === appFilter ? ' on' : ''); c.textContent = t; c.dataset.k = k;
  c.addEventListener('click', () => { appFilter = k; $$('#app-filter .chip').forEach(x => x.classList.toggle('on', x.dataset.k === k)); renderApps(); haptic(); }); $('#app-filter').appendChild(c); });
$$('#app-tabs button').forEach(b => b.addEventListener('click', () => {
  $$('#app-tabs button').forEach(x => x.classList.toggle('active', x === b));
  $('#app-tabs').classList.toggle('second', b.dataset.tab === 'debloat');
  $('#tab-manage').hidden = b.dataset.tab !== 'manage'; $('#tab-debloat').hidden = b.dataset.tab !== 'debloat';
  if (b.dataset.tab === 'debloat') loadDebloat(); haptic();
}));
async function loadExcl() { const r = await callFast('excl_get'); if (r.ok && r.data) excl = new Set(r.data); }
async function loadApps(force) {
  if (appsLoaded && !force) return;
  $('#app-count').textContent = 'Loading apps...';
  const r = await callFast('apps_list'); if (!r.ok || !r.data) { $('#app-count').textContent = r.msg || 'Failed to load apps'; return; }
  appsAll = r.data; appsLoaded = true; renderApps();
}
$('#app-q').addEventListener('input', () => renderApps());
function renderApps() {
  const q = $('#app-q').value.trim().toLowerCase();
  let l = appsAll.filter(a => (appFilter === 'all') || (appFilter === 'user' && !a.s) || (appFilter === 'system' && a.s) || (appFilter === 'disabled' && !a.e) || (appFilter === 'excl' && excl.has(a.p)));
  if (q) l = l.filter(a => a.n.toLowerCase().includes(q) || a.p.toLowerCase().includes(q));
  l.sort((a, b) => a.n.localeCompare(b.n));
  $('#app-count').textContent = l.length + ' apps' + (l.length > 150 ? ' (showing first 150, use search)' : '');
  const box = $('#app-list'); box.innerHTML = '';
  if (!l.length) { box.innerHTML = emptyLog('No apps match'); return; }
  const frag = document.createDocumentFragment();
  l.slice(0, 150).forEach(a => {
    const d = document.createElement('div'); d.className = 'arow';
    d.innerHTML = '<div class="at"><b></b><small></small></div><div class="tags"></div>';
    d.insertBefore(avatar(a.n, a.p), d.firstChild);
    $('b', d).textContent = a.n; $('small', d).textContent = a.p;
    $('.tags', d).innerHTML = (a.s ? '<span class="pill">SYS</span>' : '') + (a.e ? '' : '<span class="pill bad">OFF</span>') + (a.l ? '<span class="pill shizuku">LOCK</span>' : '') + (excl.has(a.p) ? '<span class="pill good">EXCL</span>' : '');
    d.addEventListener('click', () => openApp(a)); frag.appendChild(d);
  });
  box.appendChild(frag);
}
async function openApp(a) {
  haptic(); const sh = $('#sheet'); $('#sheet-title').textContent = a.n; $('#sheet-body').textContent = 'Loading...'; $('#sheet-actions').innerHTML = '';
  const av = $('#sheet-ai'); av.innerHTML = ''; fillAvatar(av, a.n, a.p); if (!iconCache.has(a.p)) wantIcon(a.p);
  sh.classList.add('show');
  const r = await callFast('app_details', { pkg: a.p }); if (!r.ok) { $('#sheet-body').textContent = r.msg || 'Failed'; return; } const d = r.data;
  $('#sheet-body').innerHTML = '<div class="kv">' + KV([['Package', d.p], ['Version', d.ver], ['Type', d.sys ? 'System app' : 'User app'], ['State', d.enabled ? 'Enabled' : 'Disabled', d.enabled ? 'good' : 'bad'], ['Size (APK)', d.sizeMb + ' MB'], ['Installer', d.installer || 'unknown']]) + '</div>' + (d.lock ? '<p class="hint warn">Protected package: it cannot be disabled or uninstalled from here.</p>' : '');
  const acts = $('#sheet-actions');
  const add = (label, icon, fn, dis) => { const b = document.createElement('button'); b.className = 'btn'; b.innerHTML = '<i class="fa-solid ' + icon + '"></i> ' + label; b.disabled = !!dis; b.addEventListener('click', fn); acts.appendChild(b); };
  add('Launch', 'fa-play', async () => { const x = await call('app_launch', { pkg: d.p }); if (!x.ok) toast(x.msg, 'error'); }, !d.launch);
  add('App settings', 'fa-gear', () => call('app_settings', { pkg: d.p }));
  add(excl.has(d.p) ? 'Remove exclusion' : 'Exclude from cleaner', 'fa-shield', async () => { excl.has(d.p) ? excl.delete(d.p) : excl.add(d.p); await call('excl_set', { list: [...excl] }); toast('Exclusion list updated', 'success'); $('#sheet').classList.remove('show'); renderApps(); });
  if (!d.sys) add('Uninstall', 'fa-trash', async () => { if (await modal('Uninstall ' + d.n + '?', 'Android will ask you to confirm. App data will be lost.', 'Continue')) { const x = await call('app_uninstall', { pkg: d.p }); toast(x.msg || (x.ok ? 'Opened' : 'Failed'), x.ok ? 'info' : 'error'); } }, d.lock);
  add(d.enabled ? 'Disable' : 'Enable', d.enabled ? 'fa-ban' : 'fa-circle-check', async () => {
    if (rank() < 1) return toast('Enable Shizuku or Root first (HOME \u2192 Access Mode)', 'error');
    if (!await modal((d.enabled ? 'Disable ' : 'Enable ') + d.n + '?', d.enabled ? 'The app will stop running and disappear from the launcher. You can re-enable it here at any time.' : 'The app will be re-enabled.', 'Confirm')) return;
    const x = await call('debloat_apply', { action: d.enabled ? 'disable' : 'enable', pkgs: [d.p] }); const row = x.data && x.data[0];
    report(!!(row && row.ok), row ? d.n + ': ' + row.msg : 'Failed'); $('#sheet').classList.remove('show'); loadApps(true); debloatLoaded = false;
  }, d.lock && d.enabled);
}
$('#sheet-close').addEventListener('click', () => $('#sheet').classList.remove('show'));
$('#sheet').addEventListener('click', e => { if (e.target.id === 'sheet') $('#sheet').classList.remove('show'); });

/* ---------- apps: debloat ---------- */
let debloatLoaded = false, dlist = []; const picked = new Set();
async function loadDebloat() {
  if (debloatLoaded) return; const box = $('#debloat-list'); box.innerHTML = emptyLog('Scanning installed packages...');
  const r = await callFast('debloat_list'); if (!r.ok) { box.innerHTML = emptyLog(esc(r.msg || 'Failed')); return; }
  dlist = r.data; debloatLoaded = true; picked.clear(); renderDebloat();
}
function renderDebloat() {
  const box = $('#debloat-list'); box.innerHTML = ''; if (!dlist.length) { box.innerHTML = emptyLog('None of the known candidates are installed here.'); $('#debloat-n').textContent = 0; return; }
  [['review', 'SAFE TO REVIEW'], ['critical', 'CRITICAL / PROTECTED (locked)']].forEach(([tier, title]) => {
    const items = dlist.filter(x => x.tier === tier); if (!items.length) return;
    const h = document.createElement('div'); h.className = 'dgroup'; h.textContent = title; box.appendChild(h);
    items.forEach(x => {
      const d = document.createElement('label'); d.className = 'drow' + (x.lock ? ' lock' : '');
      d.innerHTML = '<div class="at"><b></b> <span class="pill"></span><small class="why"></small><small class="pk"></small></div><input type="checkbox">';
      d.insertBefore(avatar(x.l, x.p), d.firstChild);
      const cb = $('input', d); cb.disabled = x.lock; cb.checked = picked.has(x.p);
      $('b', d).textContent = x.l; $('.pill', d).textContent = x.e ? x.cat : 'DISABLED'; if (!x.e) $('.pill', d).classList.add('bad');
      $('.why', d).textContent = x.why; $('.pk', d).textContent = x.p;
      cb.addEventListener('change', () => { cb.checked ? picked.add(x.p) : picked.delete(x.p); $('#debloat-n').textContent = picked.size; haptic(); });
      box.appendChild(d);
    });
  });
  $('#debloat-n').textContent = picked.size;
}
$('#debloat-preview').addEventListener('click', async () => {
  if (!picked.size) return toast('Select at least one app', 'info');
  if (rank() < 1) return toast('Enable Shizuku or Root first (HOME \u2192 Access Mode)', 'error');
  const plan = [...picked].map(p => dlist.find(x => x.p === p)).filter(Boolean);
  const dis = plan.filter(x => x.e), en = plan.filter(x => !x.e);
  const li = a => '<ul>' + a.map(x => '<li><b>' + esc(x.l) + '</b><br><small>' + esc(x.p) + '</small></li>').join('') + '</ul>';
  const html = (dis.length ? '<b>Will be disabled (reversible):</b>' + li(dis) : '') + (en.length ? '<b>Will be re-enabled:</b>' + li(en) : '') + '<p class="hint warn" style="text-align:left">To undo later: select the same app here, or open it in MANAGE and tap Enable.</p>';
  if (!await modal('Planned actions', html, 'Execute')) return;
  haptic(); let lines = [];
  for (const [action, arr] of [['disable', dis], ['enable', en]]) {
    if (!arr.length) continue; const r = await call('debloat_apply', { action, pkgs: arr.map(x => x.p) });
    (r.data || []).forEach(x => lines.push((x.ok ? '\u2705 ' : '\u274C ') + esc(x.p) + ' \u2014 ' + esc(x.msg)));
  }
  await modal('Result', '<pre>' + lines.join('\n') + '</pre>', 'Done', null);
  debloatLoaded = false; appsLoaded = false; loadDebloat(); setTimeout(loadLog, 300);
});

/* ---------------------------------------------------------------- quick: deep optimization / safety tiles */
const EXTRA = [
  { id: 'bgdexopt', name: 'Dexopt', sub: 'Android\'s own app optimization job', icon: 'fa-gears', c: '#2ed573' },
  { id: 'speedprofile', name: 'Recompile', sub: 'Profile-guided recompile of all apps', icon: 'fa-microchip', c: '#ff4dd2' },
  { id: 'fstrim', name: 'Trim storage', sub: 'Discard unused filesystem blocks', icon: 'fa-hard-drive', c: '#ffa502' }
];
EXTRA.forEach(x => tile($('#extra-grid'), { id: 'x-' + x.id, name: x.name, sub: x.sub, icon: x.icon, c: x.c, tag: 'HEAVY', run: async b => {
  if (rank() < 1) return toast('Enable Shizuku or Root first (HOME \u2192 Access Mode)', 'error');
  haptic(); b.classList.add('busy'); let r = await call('extra_run', { kind: x.id });
  if (r.confirm) { b.classList.remove('busy'); if (!await modal('Run again?', esc(r.msg), 'Run anyway')) return; b.classList.add('busy'); r = await call('extra_run', { kind: x.id, force: true }); }
  b.classList.remove('busy'); report(r.ok, r.msg || 'Failed'); refreshExtra();
} }));
tile($('#tool-grid'), { id: 't-cd', name: 'Cooldown', sub: 'Emergency cool-down steps', icon: 'fa-temperature-arrow-down', c: '#29b6f6', run: () => { haptic(); refreshCooldown(); $('#cd-sheet').classList.add('show'); } });
tile($('#tool-grid'), { name: 'View log', sub: 'Recent warnings & errors', icon: 'fa-file-lines', c: '#a855f7', run: async () => { haptic(); const r = await call('log_view'); await modal('Recent warnings & errors', '<pre>' + esc(r.data || r.msg || 'No output') + '</pre>', 'Close', null); } });
tile($('#tool-grid'), { name: 'Clear logcat', sub: 'Empty debug log buffers', icon: 'fa-eraser', c: '#ff6b81', run: async () => {
  if (!await modal('Clear logcat buffers?', 'This empties the on-device debug log buffers. Android security/audit logs are not touched, and nothing else is deleted.', 'Clear')) return;
  const r = await call('logcat_clear'); report(r.ok, r.msg || 'Failed');
} });

async function refreshExtra() {
  for (const x of EXTRA) {
    if (x.id === 'fstrim') continue;
    const r = await callFast('extra_status', { kind: x.id }); const s = $('#x-' + x.id + ' .qs'); if (!s || !r.ok) continue;
    s.textContent = r.state === 'running' ? 'Running... status updates when it ends' : r.state.startsWith('done:0') ? 'Last run finished OK' : r.state.startsWith('done:') ? 'Last run ended with code ' + r.state.slice(5) : (r.last ? 'Last started ' + fmtAgo(r.last) : $('#x-' + x.id).dataset.def);
  }
  const t = await callFast('extra_sched_get'); if (t.ok) { $('#extra-sched').checked = !!t.on; $('#extra-last').textContent = 'Last background dexopt: ' + fmtAgo(t.lastRun) + '. Android picks the time (charging + idle).'; }
  if ($('#x-bgdexopt .qs').textContent.startsWith('Running')) setTimeout(() => { if (page === 'quick') refreshExtra(); }, 5000);
}
$('#extra-sched').addEventListener('change', async e => { const r = await call('extra_sched', { on: e.target.checked }); if (!r.ok) e.target.checked = !e.target.checked; report(r.ok, r.msg || 'Failed'); });
$('#extra-reset').addEventListener('click', async () => { haptic(); const r = await call('reset'); if (r.ok) setProfileUI('', null); report(r.ok, r.ok ? 'Optimization settings reset' : (r.msg || 'Reset failed')); });

/* cooldown sheet */
const cdSheet = $('#cd-sheet');
$('#cd-close').addEventListener('click', () => cdSheet.classList.remove('show'));
cdSheet.addEventListener('click', e => { if (e.target === cdSheet) cdSheet.classList.remove('show'); });
$('#cd-run').addEventListener('click', async () => {
  const steps = $$('[data-cd]').filter(i => i.checked).map(i => i.dataset.cd); if (!steps.length) return toast('Pick at least one step', 'info');
  const risky = steps.includes('airplane');
  cdSheet.classList.remove('show');
  const ok = await modal('Emergency cooldown', '<ul>' + steps.map(s => '<li>' + ({ overlay: 'Stop the stats overlay', ai: 'Stop the Auto AI loop', bgkill: 'Close background apps', battsaver: 'Turn battery saver on', airplane: '<b>Airplane mode ON</b>' }[s]) + '</li>').join('') + '</ul>' +
    (risky ? '<p class="hint warn" style="text-align:left"><b>Airplane mode will cut calls, mobile data, Wi-Fi and notifications</b> until restored.</p>' : '') + '<p>Temporary changes are restored after 10 minutes or when you tap Restore.</p>', 'Cool down');
  if (!ok) return; haptic(); const r = await call('cooldown', { steps }); report(r.ok, r.msg || 'Failed'); refreshCooldown();
});
$('#cd-restore').addEventListener('click', async () => { cdSheet.classList.remove('show'); const r = await call('cooldown_restore'); report(r.ok, r.msg || 'Failed'); refreshCooldown(); });
async function refreshCooldown() {
  const r = await callFast('cooldown_get'); const act = !!(r.ok && r.data && r.data.length);
  $('#cd-restore').hidden = !act;
  const t = $('#t-cd'); let tg = $('.live-pill', t);
  if (act && !tg) { tg = document.createElement('span'); tg.className = 'pill good live-pill'; tg.textContent = 'ACTIVE'; $('.fx', t).prepend(tg); } else if (!act && tg) tg.remove();
}

/* ---------- settings: permissions + capability scan ---------- */
const PERM_ACT = { overlay: () => native('openSystem', 'overlay'), notif: () => native('openSystem', 'notif'), battery: () => native('openSystem', 'battery'), shizuku: () => native('openShizuku'), root: () => native('selectMode', 'root') };
async function refreshPerms() {
  const r = await callFast('perm_status'); if (!r.ok || !r.data) return; const box = $('#perm-list'); box.innerHTML = '';
  r.data.forEach(p => { const d = document.createElement('div'); d.className = 'crow'; paint(d, p.ok ? '#2ed573' : '#ffa502');
    d.innerHTML = '<div class="ci"><i class="fas ' + (p.ok ? 'fa-check' : 'fa-exclamation') + '"></i></div><div class="ft"><b></b><small></small></div><span class="pill ' + (p.ok ? 'good' : 'warn') + '">' + (p.ok ? 'GRANTED' : 'NOT GRANTED') + '</span>';
    $('b', d).textContent = p.name; $('small', d).textContent = p.why;
    if (!p.ok) { const b = document.createElement('button'); b.className = 'mini-btn'; b.textContent = p.id === 'root' ? 'Check root' : p.id === 'shizuku' ? 'Open Shizuku' : 'Open settings'; b.addEventListener('click', PERM_ACT[p.id]); $('.ft', d).appendChild(b); }
    box.appendChild(d); });
}
const ST = { supported: 'SUPPORTED', partial: 'PARTIAL', permission: 'PERMISSION REQUIRED', shizuku: 'SHIZUKU REQUIRED', root: 'ROOT REQUIRED', unsupported: 'KERNEL/DEVICE UNSUPPORTED', failed: 'FAILED', untested: 'NOT TESTED' };
const STC = { supported: '#2ed573', partial: '#ffa502', permission: '#ffa502', untested: '#ffa502', shizuku: '#9d4edd', root: '#9d4edd', unsupported: '#ff6b81', failed: '#ff6b81' };
$('#caps-scan').addEventListener('click', async () => {
  haptic(); const b = $('#caps-scan'); b.disabled = true; b.innerHTML = '<i class="fa-solid fa-spinner fa-spin"></i> Scanning...';
  const r = await call('caps_scan'); b.disabled = false; b.innerHTML = '<i class="fa-solid fa-magnifying-glass-chart"></i> Run scan';
  if (!r.ok || !r.data) return toast(r.msg || 'Scan failed', 'error');
  const box = $('#caps-list'); box.innerHTML = '';
  r.data.forEach(c => { const d = document.createElement('div'); d.className = 'crow'; paint(d, STC[c.status] || '#9d4edd');
    d.innerHTML = '<div class="ci"><i class="fas ' + (c.status === 'supported' ? 'fa-check' : c.status === 'failed' || c.status === 'unsupported' ? 'fa-xmark' : 'fa-minus') + '"></i></div><div class="ft"><b></b><small></small></div><span class="pill ' + c.status + '">' + ST[c.status] + '</span>';
    $('b', d).textContent = c.name; $('small', d).textContent = c.detail; box.appendChild(d); });
});

/* ---------------------------------------------------------------- matrix rain */
let rainOn = store.get('rain', true);
(function rain() {
  const c = $('#rain'), x = c.getContext('2d'); let cols, drops;
  function size() { c.width = innerWidth; c.height = innerHeight; cols = Math.floor(c.width / 14); drops = Array.from({ length: cols }, () => Math.random() * -50); }
  size(); addEventListener('resize', size);
  if (!rainOn) c.style.display = 'none';
  setInterval(() => {
    if (!rainOn || document.hidden) return;
    x.fillStyle = 'rgba(4,5,13,.12)'; x.fillRect(0, 0, c.width, c.height);
    x.fillStyle = getComputedStyle(document.documentElement).getPropertyValue('--accent').trim() || '#0f8'; x.font = '13px monospace';
    for (let i = 0; i < cols; i++) {
      x.fillText(Math.random() > .5 ? '1' : '0', i * 14, drops[i] * 14);
      if (drops[i] * 14 > c.height && Math.random() > .975) drops[i] = 0;
      drops[i]++;
    }
  }, 60);
})();

/* ---------------------------------------------------------------- boot */
async function refreshStatus() {
  const raw = native('getStatus'); if (raw) { try { applyStatus(JSON.parse(raw)); } catch (e) {} }
}
setInterval(() => { if (!document.hidden && page === 'home') refreshStatus(); }, 4000);
window.addEventListener('load', () => {
  stagger(); refreshStatus(); placeIndicator(); loadLog(); loadExcl();
  setTimeout(() => { $('#loading').classList.add('hide'); placeIndicator(); }, 900);
});
if (document.fonts && document.fonts.ready) document.fonts.ready.then(placeIndicator);

/* ---------------------------------------------------------------- mock (browser preview only) */
function installMock() {
  const s = { mode: 'shizuku', shizukuInstalled: true, shizukuRunning: true, shizukuGranted: true, sdk: 34, device: 'Preview Phone', soc: 'Snapdragon', profile: 'auto', ai: { on: true, profile: 'daytoday', reason: 'Battery 62%, temp 36 C' }, boot: false };
  const t = { dnd: { on: false }, bypass: { on: true, supported: true }, battery_saver: { on: false }, hi_refresh: { on: true }, fast_anim: { on: false }, stay_awake: { on: false } };
  const apps = ['Chrome:com.android.chrome', 'WhatsApp:com.whatsapp', 'Instagram:com.instagram.android', 'YouTube:com.google.android.youtube', 'Telegram:org.telegram.messenger', 'Spotify:com.spotify.music'];
  const svg = (l, h) => 'data:image/svg+xml;utf8,' + encodeURIComponent('<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 96 96"><rect width="96" height="96" fill="hsl(' + h + ',70%,45%)"/><circle cx="48" cy="48" r="26" fill="white" opacity=".85"/><text x="48" y="58" font-size="30" text-anchor="middle" fill="hsl(' + h + ',70%,35%)" font-family="sans-serif">' + l + '</text></svg>');
  window.KayrootApp = {
    getStatus: () => JSON.stringify(s),
    getStats: () => JSON.stringify({ battery: { level: 62, temp: 36.4, charging: false, voltage: 4012 }, ram: { usedMb: 4210, totalMb: 7600, pct: 55 }, storage: { freeGb: 88.2, totalGb: 256, pct: 66 } }),
    selectMode: m => { s.mode = m; window.onKayrootStatus(s); },
    openShizuku() {}, haptic() {}, openSystem() {},
    fastCall: (a, args, cb) => setTimeout(() => {
      let r = { ok: true, msg: '' };
      if (a === 'mon_sample') r.data = { cores: 8, cpuPct: 20 + Math.random() * 40, freqMhz: [1800, 2400, 2800], gpuPct: null, gpuMhz: null, cpuTemp: 41.2, thermal: 'None', ram: { totalMb: 7600, availMb: 3300, usedMb: 4300, pct: 56, cachedMb: 2100, swapTotalMb: 2048, swapFreeMb: 1900, pressure: 'Normal' }, battery: { tempC: 36.4 }, mode: 'shizuku' };
      else if (a === 'batt_info') r.data = { level: 62, voltageMv: 4012, tempC: 36.4, status: 'Discharging', plugged: 'No', health: 'Good', currentMa: -420, powerW: 1.7, chargeNowMah: 2900, estFullMah: 4680, cycles: null, battOptIgnored: false };
      else if (a === 'overlay_cfg_get') r.data = { running: false, perm: true, stats: 'fps,cpu,ram,bat,temp', alpha: 80, size: 12, interval: 1500 };
      else if (a === 'log_get') r.data = [];
      else if (a === 'perm_status') r.data = [{ id: 'overlay', name: 'Display over other apps', why: 'Overlay only', ok: false }, { id: 'shizuku', name: 'Shizuku', why: 'Unlocks pro features', ok: true }];
      else if (a === 'cooldown_get' || a === 'excl_get') r.data = [];
      else if (a === 'extra_status') { r.state = ''; r.last = 0; }
      else if (a === 'extra_sched_get') { r.on = false; r.lastRun = 0; }
      else if (a === 'app_icons') { r.data = {}; JSON.parse(args).pkgs.forEach(p => { const i = apps.findIndex(x => x.split(':')[1] === p); if (i >= 0) r.data[p] = svg(apps[i][0], i * 55); }); }
      window[cb](r);
    }, 200),
    call: (a, args, cb) => setTimeout(() => {
      const A = JSON.parse(args); let r = { ok: true, msg: '' };
      if (a === 'toggle_get_all') r.data = t;
      else if (a === 'toggle_set') { t[A.key].on = A.on; }
      else if (a === 'gov_info') r.data = { current: 'schedutil', available: ['performance', 'schedutil', 'powersave', 'conservative'] };
      else if (a === 'profile') s.profile = A.name;
      else if (a === 'apps_list') r.data = apps.map(x => ({ n: x.split(':')[0], p: x.split(':')[1], s: false, e: true, l: false })).concat([{ n: 'Facebook Services', p: 'com.facebook.services', s: true, e: true, l: false }, { n: 'Calculator', p: 'com.android.calculator2', s: true, e: false, l: false }]);
      else if (a === 'app_details') r.data = { p: A.pkg, n: A.pkg, ver: '1.0 (1)', sys: false, enabled: true, sizeMb: 42.1, installer: 'com.android.vending', lock: false, launch: true };
      else if (a === 'debloat_list') r.data = [{ p: 'com.facebook.services', l: 'Facebook Services', cat: 'Preinstalled', why: 'Support service for the Facebook app.', tier: 'review', e: true, lock: false }, { p: 'com.google.android.gms', l: 'Google Play services', cat: 'Critical', why: 'Do not disable.', tier: 'critical', e: true, lock: true }];
      window[cb](r);
    }, 400)
  };
}
})();
