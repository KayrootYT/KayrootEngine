# Feature matrix (v2.3) - honest status

Status is "written, NOT yet compiled or tested on a device". Verify each row on your phone with Settings > Capability scan.

| Feature | Access | Status | Limits |
|---|---|---|---|
| Access modes Basic / Shizuku / Root | - | existing | Shizuku cannot write sysfs |
| AI engine: Power Save / Auto / Performance, start/stop/restart, last decision | Shizuku or Root | implemented | Auto = adaptive rules engine, not ML |
| Capability scan + permission checklist | all | implemented | statuses come from live probes |
| CPU %, clock, GPU, CPU temp | Shizuku/Root | implemented | Basic mode shows N/A; GPU only on Adreno (kgsl) paths |
| Thermal status, RAM, pressure, swap, cached | all | implemented | thermal status needs Android 10+ |
| Battery (level, V, temp, health category, current, power, capacity estimate, cycles) | all | implemented | current/power/cycles only if vendor exposes them; capacity is an estimate |
| Frame time / FPS | Shizuku/Root | partial | SurfaceFlinger layer of foreground app; not universal |
| Floating overlay (drag, pin, collapse, close, opacity, size, interval, stat picker) | overlay permission | implemented | pauses when screen off |
| App manage (list, search, filter, details, launch, settings, uninstall) | all | implemented | uninstall uses Android's dialog |
| Disable/enable apps, debloat with preview + confirm | Shizuku/Root | implemented | protected packages locked; list is a review starting point |
| Cleaner exclusion list | all | implemented | honoured when closing background apps and by the Root cache cleaner; Shizuku `pm trim-caches` is system-wide and cannot exclude |
| Cleaning, logcat view/clear | Shizuku/Root for full | implemented | other apps' cache only via Shizuku/Root |
| Extra optimization: bg dexopt, speed-profile, trim, daily schedule, reset | Shizuku/Root | implemented | no real progress %, only running/done state; trim result is device dependent |
| Emergency cooldown + restore | partial | implemented | airplane/battery saver need Shizuku/Root; auto-restore after 10 min, also resumed when the app is reopened after being killed |
| Quick Settings tile | Shizuku/Root | implemented | toggles Auto AI |
| Persistent operation history | all | implemented | last 60 entries |
| Auto AI custom rules (IF temp/battery THEN profile), night schedule, no-game-on-charger, switch cooldown | Shizuku or Root | implemented (v2.3) | max 10 rules; thermal protection at 46 C cannot be overridden |
| User game list ("Mark as game" in APPS) + Play category/FLAG_IS_GAME detection | Shizuku or Root | implemented (v2.3) | detection reads the foreground app via dumpsys |
| Settings backup / restore (JSON via share sheet + paste) | all | implemented (v2.3) | allow-listed keys only, values validated on import |
| Local crash log (view / share / clear) | all | implemented (v2.3) | never uploaded |
| Light / dark / auto mode | all | implemented (v2.3) | matrix rain is disabled in light mode |
| Root re-verified before root scripts (max once a minute) | Root | implemented (v2.3) | falls back to Basic if root was revoked |
| Bridge hardening: only bundled pages may call the bridge, package names validated | all | implemented (v2.3) | |
| JVM unit tests for the Auto AI rules | - | written (v2.3) | run by CI (`gradle :app:testDebugUnitTest`); not yet run by the author |
| Debug toggle, privacy text | all | implemented | |

## Not implemented yet
- Screen-off battery/background policy, Data Saver integration
- Sound notifications, battery notification, Wi-Fi sleep options
- Profiles "Screen-Off" and "Custom" (existing 4 profiles are used)
- Separate NonRoot/Shizuku/Root provider classes (AccessManager still does the routing)
- Unit tests for Monitor parsing and Api.route (only Auto AI rules are covered)
- Real progress % for dexopt / recompile (Android does not expose one; the app shows elapsed time)
- FPS fallback via Choreographer (it only measures this app's own frames, so it would be misleading)
- Per-app profiles and learning, Wi-Fi sleep, Data Saver, custom governor/animation profiles
