package com.kayroot.engine;

// Runs inside the Shizuku "user service" process (shell uid 2000).
interface IShellService {
    // Reserved transaction code used by Shizuku to tear the service down.
    void destroy() = 16777114;

    // Returns [exitCode, stdout, stderr]
    String[] exec(String script, long timeoutMs) = 1;
}
