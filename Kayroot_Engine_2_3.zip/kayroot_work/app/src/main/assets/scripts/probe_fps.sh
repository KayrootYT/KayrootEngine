FG=$(dumpsys activity activities 2>/dev/null | grep -m1 -E 'topResumedActivity|mResumedActivity' | sed -E 's/.* u[0-9]+ ([A-Za-z0-9_.]+)\/.*/\1/')
case "$FG" in *[!A-Za-z0-9_.]*|"") FG="";; esac
echo "FG=$FG"
[ -n "$FG" ] || exit 0
LIST=$(dumpsys SurfaceFlinger --list 2>/dev/null | grep -F "$FG")
L=$(echo "$LIST" | grep -m1 'SurfaceView')
[ -n "$L" ] || L=$(echo "$LIST" | tail -n 1)
echo "LAYER=$L"
[ -n "$L" ] && dumpsys SurfaceFlinger --latency "$L" 2>/dev/null
