# Reset (root): back to the default balanced governor
G=$(pick_gov schedutil walt interactive ondemand)
[ -n "$G" ] && setgov "$G"
