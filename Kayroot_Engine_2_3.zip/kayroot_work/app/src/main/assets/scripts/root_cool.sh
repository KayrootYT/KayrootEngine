# Cooling (root): drop to a low-power governor for ~30 s (the app restores the old one)
echo "prev_gov=$(cat /sys/devices/system/cpu/cpu0/cpufreq/scaling_governor 2>/dev/null)"
G=$(pick_gov powersave conservative schedutil)
[ -n "$G" ] && setgov "$G"
