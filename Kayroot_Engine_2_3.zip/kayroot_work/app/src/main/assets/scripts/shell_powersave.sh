# PowerSaving (Shizuku level)
ok cmd power set-fixed-performance-mode-enabled false
ok settings put global low_power 1
ok settings put global window_animation_scale 0.5
ok settings put global transition_animation_scale 0.5
ok settings put global animator_duration_scale 0.5
