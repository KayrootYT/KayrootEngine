# GameBooster (root): max CPU governor
G=$(pick_gov performance)
[ -n "$G" ] && setgov "$G"
