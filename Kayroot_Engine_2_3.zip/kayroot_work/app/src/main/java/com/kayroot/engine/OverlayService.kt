package com.kayroot.engine

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import android.provider.Settings
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.TextView
import java.util.Locale

/** Frame-time bars: green <= 17.5 ms, amber <= 34 ms, red above. */
class FrameGraph(ctx: Context) : View(ctx) {
    private var data: List<Double> = emptyList()
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val d = ctx.resources.displayMetrics.density

    fun set(v: List<Double>) { data = v; invalidate() }

    override fun onMeasure(w: Int, h: Int) {
        setMeasuredDimension(resolveSize((170 * d).toInt(), w), (38 * d).toInt())
    }

    override fun onDraw(c: Canvas) {
        if (data.isEmpty()) return
        val n = data.size
        val bw = width.toFloat() / n
        for (i in 0 until n) {
            val v = data[i]
            val h = (minOf(v, 50.0) / 50.0 * height).toFloat()
            p.color = when {
                v <= 17.5 -> 0xFF2ED573.toInt()
                v <= 34.0 -> 0xFFFFA502.toInt()
                else -> 0xFFFF4D6D.toInt()
            }
            c.drawRect(i * bw, height - h, (i + 1) * bw - 1f, height.toFloat(), p)
        }
    }
}

/**
 * Floating statistics overlay. FPS is read from SurfaceFlinger's frame timestamps of the foreground app's layer,
 * so it needs Shizuku or Root and may be N/A for some apps (secure/protected layers, apps that draw rarely).
 */
class OverlayService : Service() {

    companion object {
        @Volatile var running = false
        private const val CH = "kayroot_overlay"

        fun start(ctx: Context) {
            val i = Intent(ctx, OverlayService::class.java)
            if (Build.VERSION.SDK_INT >= 26) ctx.startForegroundService(i) else ctx.startService(i)
        }

        fun stop(ctx: Context) { ctx.stopService(Intent(ctx, OverlayService::class.java)) }
    }

    private lateinit var wm: WindowManager
    private lateinit var lp: WindowManager.LayoutParams
    private var box: LinearLayout? = null
    private var body: LinearLayout? = null
    private var statsView: TextView? = null
    private var graph: FrameGraph? = null
    private val ui = Handler(Looper.getMainLooper())
    private val prefs by lazy { getSharedPreferences("kayroot", Context.MODE_PRIVATE) }
    @Volatile private var alive = false
    private var pinned = false
    private val fpsHist = ArrayList<Double>()

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (!Settings.canDrawOverlays(this)) { stopSelf(); return START_NOT_STICKY }
        goForeground()
        if (box == null) buildView()
        running = true
        if (!alive) {
            alive = true
            Thread { loop() }.apply { isDaemon = true; start() }
        }
        return START_NOT_STICKY
    }

    override fun onDestroy() {
        alive = false
        running = false
        try { box?.let { wm.removeView(it) } } catch (_: Exception) {}
        box = null
        super.onDestroy()
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun goForeground() {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= 26) nm.createNotificationChannel(NotificationChannel(CH, "Stats overlay", NotificationManager.IMPORTANCE_LOW))
        val pi = PendingIntent.getActivity(this, 1, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        val n = (if (Build.VERSION.SDK_INT >= 26) Notification.Builder(this, CH) else Notification.Builder(this))
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle("Kayroot stats overlay")
            .setContentText("Tap to open. Close the overlay from its X button.")
            .setContentIntent(pi).setOngoing(true).build()
        if (Build.VERSION.SDK_INT >= 34) startForeground(2, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        else startForeground(2, n)
    }

    private fun buildView() {
        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        val alpha = prefs.getInt("ov_alpha", 80).coerceIn(20, 100)
        val size = prefs.getInt("ov_size", 12).coerceIn(9, 20).toFloat()

        val bg = GradientDrawable().apply {
            setColor(Color.argb(alpha * 255 / 100, 6, 8, 20))
            cornerRadius = dp(14).toFloat()
            setStroke(dp(1), Color.argb(170, 0, 245, 212))
        }
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = bg
            setPadding(dp(10), dp(4), dp(8), dp(8))
        }
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val title = TextView(this).apply {
            text = "KAYROOT"; setTextColor(0xFF00F5D4.toInt()); textSize = size - 1
            typeface = Typeface.DEFAULT_BOLD
        }
        header.addView(title, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))

        fun btn(t: String, onClick: (TextView) -> Unit): TextView {
            val tv = TextView(this)
            tv.text = t; tv.setTextColor(Color.WHITE); tv.textSize = 16f
            tv.setPadding(dp(12), dp(8), dp(6), dp(8))
            tv.setOnClickListener { onClick(tv) }
            return tv
        }
        header.addView(btn("\uD83D\uDCCC") { tv -> pinned = !pinned; tv.alpha = if (pinned) 1f else 0.45f }.also { it.alpha = 0.45f })
        header.addView(btn("\u25BE") { tv ->
            val b = body ?: return@btn
            val hide = b.visibility == View.VISIBLE
            b.visibility = if (hide) View.GONE else View.VISIBLE
            tv.text = if (hide) "\u25B8" else "\u25BE"
        })
        header.addView(btn("\u2715") { stopSelf() })
        root.addView(header)

        val b = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val st = TextView(this).apply {
            setTextColor(Color.WHITE); textSize = size; typeface = Typeface.MONOSPACE
            text = "Starting..."
        }
        val g = FrameGraph(this)
        b.addView(st); b.addView(g)
        root.addView(b)
        body = b; statsView = st; graph = g

        lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = Gravity.TOP or Gravity.START
        lp.x = prefs.getInt("ov_x", dp(12)); lp.y = prefs.getInt("ov_y", dp(120))

        header.setOnTouchListener(object : View.OnTouchListener {
            var sx = 0; var sy = 0; var tx = 0f; var ty = 0f
            override fun onTouch(v: View, e: MotionEvent): Boolean {
                if (pinned) return false
                when (e.action) {
                    MotionEvent.ACTION_DOWN -> { sx = lp.x; sy = lp.y; tx = e.rawX; ty = e.rawY }
                    MotionEvent.ACTION_MOVE -> {
                        lp.x = sx + (e.rawX - tx).toInt(); lp.y = sy + (e.rawY - ty).toInt()
                        try { wm.updateViewLayout(root, lp) } catch (_: Exception) {}
                    }
                    MotionEvent.ACTION_UP -> prefs.edit().putInt("ov_x", lp.x).putInt("ov_y", lp.y).apply()
                }
                return true
            }
        })
        try { wm.addView(root, lp); box = root } catch (e: Exception) { stopSelf() }
    }

    // ------------------------------------------------------------------ sampling
    private fun loop() {
        val access = AccessManager(this)
        val mon = Monitor(this, access)
        val pmgr = getSystemService(Context.POWER_SERVICE) as PowerManager
        val fpsScript = assets.open("scripts/probe_fps.sh").bufferedReader().use { it.readText() }
        while (alive) {
            val interval = prefs.getInt("ov_interval", 1500).coerceIn(500, 10_000).toLong()
            try {
                if (pmgr.isInteractive) {   // no work while the screen is off
                    val on = (prefs.getString("ov_stats", "fps,cpu,ram,bat,temp") ?: "").split(",")
                    val s = mon.sample()
                    var fps: Double? = null
                    var frames: List<Double> = emptyList()
                    if ("fps" in on && access.mode != Mode.BASIC) {
                        val r = readFps(access, fpsScript)
                        if (r != null) { fps = r.first; frames = r.second }
                    }
                    if (fps != null) { fpsHist.add(fps); if (fpsHist.size > 30) fpsHist.removeAt(0) }
                    val sb = StringBuilder()
                    if ("fps" in on) {
                        sb.append(if (fps != null) String.format(Locale.US, "FPS %.0f  avg %.0f\n", fps, fpsHist.average())
                                  else if (access.mode == Mode.BASIC) "FPS N/A (needs Shizuku/Root)\n" else "FPS N/A\n")
                    }
                    if ("cpu" in on) {
                        val c = if (s.isNull("cpuPct")) "N/A" else String.format(Locale.US, "%.0f%%", s.getDouble("cpuPct"))
                        val f = s.optJSONArray("freqMhz")
                        val mx = if (f == null || f.length() == 0) "" else "  " + (0 until f.length()).maxOf { f.getInt(it) } + "MHz"
                        sb.append("CPU $c$mx\n")
                    }
                    if ("gpu" in on) {
                        val g = if (s.isNull("gpuPct")) "N/A" else String.format(Locale.US, "%.0f%%", s.getDouble("gpuPct"))
                        sb.append("GPU $g\n")
                    }
                    if ("ram" in on) {
                        val r = s.getJSONObject("ram")
                        sb.append("RAM ${r.getLong("usedMb")}/${r.getLong("totalMb")} MB\n")
                    }
                    val b = s.getJSONObject("battery")
                    if ("bat" in on) sb.append("BAT ${b.getInt("level")}%  ${b.getString("status")}\n")
                    if ("temp" in on) {
                        val t = if (b.isNull("tempC")) "N/A" else String.format(Locale.US, "%.1f\u00b0C", b.getDouble("tempC"))
                        sb.append("TEMP $t\n")
                    }
                    if ("pwr" in on) {
                        val w = if (b.isNull("powerW")) "N/A" else String.format(Locale.US, "~%.1f W", b.getDouble("powerW"))
                        sb.append("PWR $w\n")
                    }
                    val text = sb.toString().trimEnd()
                    val fr = frames
                    ui.post { statsView?.text = text; graph?.set(fr); graph?.visibility = if ("fps" in on) View.VISIBLE else View.GONE }
                }
            } catch (_: Exception) {}
            try { Thread.sleep(interval) } catch (_: InterruptedException) { break }
        }
    }

    /** @return fps + recent frame times (ms), or null when no usable layer/timestamps exist. */
    private fun readFps(access: AccessManager, script: String): Pair<Double, List<Double>>? {
        val r = access.execScript(script, 8000)
        val stamps = ArrayList<Long>()
        var seenPeriod = false
        for (line in r.out.lineSequence()) {
            val l = line.trim()
            if (l.isEmpty() || l.startsWith("FG=") || l.startsWith("LAYER=")) continue
            if (!seenPeriod) { seenPeriod = true; continue }   // first numeric line = refresh period
            val p = l.split(Regex("\\s+"))
            if (p.size < 3) continue
            val t = p[1].toLongOrNull() ?: continue
            if (t <= 0L || t == Long.MAX_VALUE) continue
            stamps.add(t)
        }
        if (stamps.size < 3) return null
        val use = if (stamps.size > 60) stamps.subList(stamps.size - 60, stamps.size) else stamps
        val span = (use.last() - use.first()) / 1e9
        if (span <= 0.0) return null
        val deltas = ArrayList<Double>()
        for (i in 1 until use.size) deltas.add((use[i] - use[i - 1]) / 1e6)
        return Pair((use.size - 1) / span, deltas)
    }
}
