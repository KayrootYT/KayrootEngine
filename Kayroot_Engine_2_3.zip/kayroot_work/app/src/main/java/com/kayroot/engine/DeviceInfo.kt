package com.kayroot.engine

import android.os.Build

object DeviceInfo {
    private fun prop(key: String): String =
        Shell.run(arrayOf("getprop", key), 3000)[1].trim()

    /** Same chipset families that install.sh of the Magisk module detected. */
    val soc: String by lazy {
        val all = (listOf("ro.board.platform", "ro.hardware", "ro.product.board", "ro.product.platform", "ro.chipname")
            .joinToString(" ") { prop(it) } + " " + Build.HARDWARE + " " + Build.BOARD).lowercase()
        when {
            Regex("mt6|mt8|mt67|mt68|mt69|mt81|mt87|mediatek").containsMatchIn(all) -> "Mediatek"
            Regex("sm6|sm7|sm8|sdm|msm|kona|lahaina|taro|kalama|pineapple|qcom|qualcomm").containsMatchIn(all) -> "Snapdragon"
            Regex("exynos|s5e|samsung").containsMatchIn(all) -> "Exynos"
            Regex("sc9|unisoc|spreadtrum|ums").containsMatchIn(all) -> "Unisoc"
            Regex("kirin|hisilicon").containsMatchIn(all) -> "Kirin"
            Regex("tegra|nvidia").containsMatchIn(all) -> "Tegra"
            Regex("tensor|google|whitechapel|gs\\d").containsMatchIn(all) -> "Tensor"
            else -> "Unknown"
        }
    }

    val device: String get() = "${Build.BRAND} ${Build.MODEL}"
}
