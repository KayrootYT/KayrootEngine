package com.kayroot.engine

import java.io.InputStream
import java.util.concurrent.TimeUnit

data class ExecResult(val errno: Int, val out: String, val err: String)

/** Tiny process runner shared by the app process and the Shizuku user-service process. */
object Shell {
    /** @return arrayOf(exitCode, stdout, stderr) */
    @JvmStatic
    fun run(argv: Array<String>, timeoutMs: Long): Array<String> {
        return try {
            val p = ProcessBuilder(*argv).start()
            val out = StringBuilder()
            val err = StringBuilder()
            val t1 = pump(p.inputStream, out)
            val t2 = pump(p.errorStream, err)
            try { p.outputStream.close() } catch (_: Exception) {}
            val finished = p.waitFor(timeoutMs, TimeUnit.MILLISECONDS)
            if (!finished) {
                p.destroyForcibly()
                t1.join(500); t2.join(500)
                return arrayOf("124", out.toString(), err.toString() + "timeout")
            }
            t1.join(2000); t2.join(2000)
            arrayOf(p.exitValue().toString(), out.toString(), err.toString())
        } catch (e: Exception) {
            arrayOf("127", "", e.message ?: e.javaClass.simpleName)
        }
    }

    private fun pump(s: InputStream, sb: StringBuilder): Thread {
        val t = Thread {
            try {
                s.bufferedReader().forEachLine { line ->
                    synchronized(sb) { sb.append(line).append('\n') }
                }
            } catch (_: Exception) {
            }
        }
        t.isDaemon = true
        t.start()
        return t
    }

    fun toResult(a: Array<String>): ExecResult =
        ExecResult(a.getOrNull(0)?.toIntOrNull() ?: 1, a.getOrNull(1) ?: "", a.getOrNull(2) ?: "")
}
