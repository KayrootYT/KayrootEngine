package com.kayroot.engine

import android.app.ActivityManager
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.BatteryManager
import android.os.Build
import android.os.PowerManager
import org.json.JSONObject
import java.io.File
import kotlin.math.abs

internal fun JSONObject.putN(k: String, v: Any?): JSONObject = put(k, v ?: JSONObject.NULL)

/**
 * Real metrics only. Anything the device does not expose is reported as null (UI shows N/A).
 * CPU / GPU / frequency come from sysfs/procfs read through the active access mode
 * (normal Android blocks /proc/stat for apps, so Basic mode usually returns null there).
 */
class Monitor(private val ctx: Context, private val access: AccessManager) {

    private var prevTotal = 0L
    private var prevIdle = 0L
    private val script: String by lazy {
        ctx.assets.open("scripts/probe_monitor.sh").bufferedReader().use { it.readText() }
    }

    fun resetCpu() { prevTotal = 0L; prevIdle = 0L }

    fun sample(): JSONObject {
        val r = access.execScript(script, 8000)
        var cpuPct: Double? = null
        val freqs = ArrayList<Int>()
        var gpuPct: Double? = null
        var gpuMhz: Double? = null
        var cpuTemp: Double? = null
        var section = "stat"
        for (line in r.out.lineSequence()) {
            val l = line.trim()
            if (l.isEmpty()) continue
            if (l == "--freq") { section = "freq"; continue }
            if (l == "--gpu") { section = "gpu"; continue }
            if (l == "--temp") { section = "temp"; continue }
            if (section == "stat") {
                if (l.startsWith("cpu ")) {
                    val p = l.split(Regex("\\s+")).drop(1).mapNotNull { it.toLongOrNull() }
                    if (p.size >= 5) {
                        val idle = p[3] + p[4]
                        val total = p.take(8).sum()
                        if (prevTotal > 0 && total > prevTotal) {
                            val v = ((total - prevTotal) - (idle - prevIdle)) * 100.0 / (total - prevTotal)
                            cpuPct = v.coerceIn(0.0, 100.0)
                        }
                        prevTotal = total; prevIdle = idle
                    }
                }
            } else if (section == "freq") {
                l.toLongOrNull()?.let { freqs.add((it / 1000).toInt()) }
            } else if (section == "gpu") {
                val parts = l.split(" ", limit = 2)
                val v = Regex("\\d+(\\.\\d+)?").find(parts.getOrElse(1) { "" })?.value?.toDoubleOrNull()
                if (v != null) {
                    if (parts[0].endsWith("gpu_busy_percentage")) gpuPct = v.coerceIn(0.0, 100.0)
                    else gpuMhz = if (v > 1_000_000) v / 1e6 else v / 1e3
                }
            } else if (section == "temp") {
                val idx = l.lastIndexOf(' ')
                if (idx > 0) {
                    val type = l.substring(0, idx).lowercase()
                    val raw = l.substring(idx + 1).toDoubleOrNull()
                    if (raw != null && (type.contains("cpu") || type.contains("soc") || type.contains("tsens") || type.contains("cluster"))) {
                        val c = if (raw >= 1000) raw / 1000.0 else if (raw >= 150) raw / 10.0 else raw
                        if (c in 10.0..120.0 && (cpuTemp == null || c > cpuTemp!!)) cpuTemp = c
                    }
                }
            }
        }
        val cores = Runtime.getRuntime().availableProcessors()
        val o = JSONObject()
        o.put("cores", cores)
        o.putN("cpuPct", cpuPct)
        o.putN("freqMhz", if (freqs.isEmpty()) null else org.json.JSONArray(freqs))
        o.putN("gpuPct", gpuPct)
        o.putN("gpuMhz", gpuMhz)
        o.putN("cpuTemp", cpuTemp)
        o.put("thermal", thermalStatus())
        o.put("ram", ram())
        o.put("battery", battery())
        o.put("mode", access.mode.name.lowercase())
        return o
    }

    private fun thermalStatus(): String {
        if (Build.VERSION.SDK_INT < 29) return "N/A"
        return try {
            val pm = ctx.getSystemService(Context.POWER_SERVICE) as PowerManager
            when (pm.currentThermalStatus) {
                0 -> "None"; 1 -> "Light"; 2 -> "Moderate"; 3 -> "Severe"
                4 -> "Critical"; 5 -> "Emergency"; 6 -> "Shutdown"; else -> "N/A"
            }
        } catch (e: Exception) { "N/A" }
    }

    fun ram(): JSONObject {
        val am = ctx.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val mi = ActivityManager.MemoryInfo()
        am.getMemoryInfo(mi)
        val total = mi.totalMem / 1048576
        val avail = mi.availMem / 1048576
        val kb = HashMap<String, Long>()
        try {
            File("/proc/meminfo").forEachLine { l ->
                val k = l.substringBefore(":")
                val v = Regex("\\d+").find(l.substringAfter(":"))?.value?.toLongOrNull()
                if (v != null) kb[k] = v
            }
        } catch (_: Exception) {}
        val availPct = if (total > 0) avail * 100 / total else 0
        val pressure = when {
            mi.lowMemory -> "Low memory"
            availPct < 15 -> "High"
            availPct < 30 -> "Moderate"
            else -> "Normal"
        }
        val o = JSONObject()
        o.put("totalMb", total); o.put("availMb", avail); o.put("usedMb", total - avail)
        o.put("pct", if (total > 0) ((total - avail) * 100 / total).toInt() else 0)
        o.putN("cachedMb", kb["Cached"]?.let { it / 1024 })
        o.putN("swapTotalMb", kb["SwapTotal"]?.let { it / 1024 })
        o.putN("swapFreeMb", kb["SwapFree"]?.let { it / 1024 })
        o.put("pressure", pressure)
        return o
    }

    fun battery(): JSONObject {
        val i: Intent? = ctx.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val bm = ctx.getSystemService(Context.BATTERY_SERVICE) as BatteryManager
        val level = i?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
        val scale = i?.getIntExtra(BatteryManager.EXTRA_SCALE, 100) ?: 100
        val pct = if (level >= 0 && scale > 0) level * 100 / scale else -1
        val volt = i?.getIntExtra(BatteryManager.EXTRA_VOLTAGE, 0) ?: 0
        val temp = (i?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, Int.MIN_VALUE) ?: Int.MIN_VALUE)
        val st = i?.getIntExtra(BatteryManager.EXTRA_STATUS, -1) ?: -1
        val plugged = i?.getIntExtra(BatteryManager.EXTRA_PLUGGED, 0) ?: 0
        val health = i?.getIntExtra(BatteryManager.EXTRA_HEALTH, 1) ?: 1
        val cycles = i?.getIntExtra("android.os.extra.CYCLE_COUNT", -1) ?: -1

        // CURRENT_NOW unit differs between vendors (uA or mA) -> normalise by magnitude and mark as approximate.
        val rawCur = try { bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CURRENT_NOW) } catch (e: Exception) { Int.MIN_VALUE }
        var curMa: Double? = null
        if (rawCur != Int.MIN_VALUE && rawCur != 0) curMa = if (abs(rawCur) >= 10_000) rawCur / 1000.0 else rawCur.toDouble()
        val powerW = if (curMa != null && volt > 0) (volt / 1000.0) * abs(curMa) / 1000.0 else null

        val counter = try { bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CHARGE_COUNTER) } catch (e: Exception) { Int.MIN_VALUE }
        val nowMah = if (counter > 0) counter / 1000.0 else null
        val estFull = if (nowMah != null && pct in 20..100) nowMah / (pct / 100.0) else null

        val o = JSONObject()
        o.put("level", pct)
        o.put("voltageMv", volt)
        o.putN("tempC", if (temp == Int.MIN_VALUE) null else temp / 10.0)
        o.put("status", when (st) {
            BatteryManager.BATTERY_STATUS_CHARGING -> "Charging"
            BatteryManager.BATTERY_STATUS_DISCHARGING -> "Discharging"
            BatteryManager.BATTERY_STATUS_FULL -> "Full"
            BatteryManager.BATTERY_STATUS_NOT_CHARGING -> "Not charging"
            else -> "Unknown"
        })
        o.put("charging", st == BatteryManager.BATTERY_STATUS_CHARGING || st == BatteryManager.BATTERY_STATUS_FULL)
        o.put("plugged", when (plugged) { 1 -> "AC"; 2 -> "USB"; 4 -> "Wireless"; else -> "No" })
        o.put("health", when (health) {   // category reported by Android, NOT a capacity measurement
            BatteryManager.BATTERY_HEALTH_GOOD -> "Good"
            BatteryManager.BATTERY_HEALTH_OVERHEAT -> "Overheat"
            BatteryManager.BATTERY_HEALTH_DEAD -> "Dead"
            BatteryManager.BATTERY_HEALTH_OVER_VOLTAGE -> "Over voltage"
            BatteryManager.BATTERY_HEALTH_COLD -> "Cold"
            BatteryManager.BATTERY_HEALTH_UNSPECIFIED_FAILURE -> "Failure"
            else -> "Unknown"
        })
        o.putN("technology", i?.getStringExtra(BatteryManager.EXTRA_TECHNOLOGY))
        o.putN("currentMa", curMa)
        o.putN("powerW", powerW)
        o.putN("chargeNowMah", nowMah)
        o.putN("estFullMah", estFull)
        o.putN("cycles", if (cycles > 0) cycles else null)
        return o
    }
}
