package com.kayroot.engine

import android.app.job.JobInfo
import android.app.job.JobScheduler
import android.content.ComponentName
import android.content.Context
import android.provider.Settings
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit

/** Extra Optimization (ART / dexopt / trim), scheduling and Emergency Cooldown. Every change is logged and verified. */
class Extras(private val ctx: Context, private val access: AccessManager, private val tweaks: Tweaks) {

    private val prefs = ctx.getSharedPreferences("kayroot", Context.MODE_PRIVATE)

    companion object {
        private val timer = Executors.newSingleThreadScheduledExecutor()
        private const val MIN_GAP_MS = 6 * 3600_000L
        private const val STATE = "/data/local/tmp"
        private val KINDS = setOf("bgdexopt", "speedprofile", "fstrim")
        private const val JOB_ID = 4201
    }

    private fun fail(m: String) = JSONObject().put("ok", false).put("msg", m)

    private fun detached(kind: String, cmd: String): String =
        "echo running > $STATE/kr_$kind.state; " +
        "nohup sh -c '$cmd; echo done:\$? > $STATE/kr_$kind.state' >/dev/null 2>&1 & echo started"

    // ------------------------------------------------------------------ extra optimization
    fun run(kind: String, force: Boolean): JSONObject {
        if (kind !in KINDS) return fail("Unknown operation")
        if (access.mode == Mode.BASIC) return fail("Needs Shizuku or Root (HOME > Access Mode)")
        val last = prefs.getLong("extra_last_$kind", 0L)
        val ago = System.currentTimeMillis() - last
        if (!force && last > 0 && ago < MIN_GAP_MS) {
            return JSONObject().put("ok", false).put("confirm", true)
                .put("msg", "This already ran ${ago / 60000} min ago. Repeating it so soon rarely helps and costs battery.")
        }
        val script = when (kind) {
            "bgdexopt" -> detached(kind, "cmd package bg-dexopt-job")
            "speedprofile" -> detached(kind, "cmd package compile -m speed-profile -a")
            else -> if (access.mode == Mode.ROOT) "fstrim -v /data" else "sm fstrim"
        }
        val r = access.execScript(script, 60_000)
        val ok = if (kind == "fstrim") r.errno == 0 else (r.errno == 0 && r.out.contains("started"))
        if (!ok) return fail(r.err.trim().ifEmpty { r.out.trim() }.take(140).ifEmpty { "Not supported on this device in ${access.mode.name.lowercase()} mode" })
        prefs.edit().putLong("extra_last_$kind", System.currentTimeMillis()).putLong("last_opt", System.currentTimeMillis()).apply()
        val msg = when (kind) {
            "fstrim" -> "Trim requested" + (r.out.lineSequence().firstOrNull { it.isNotBlank() }?.let { ": " + it.trim() } ?: "")
            else -> "Started in background. Keep the phone charging, it can take several minutes."
        }
        return JSONObject().put("ok", true).put("msg", msg)
    }

    fun status(kind: String): JSONObject {
        if (kind !in KINDS || kind == "fstrim") return JSONObject().put("ok", true).put("state", "")
        if (access.mode == Mode.BASIC) return JSONObject().put("ok", true).put("state", "")
        val r = access.execScript("cat $STATE/kr_$kind.state 2>/dev/null", 5000)
        return JSONObject().put("ok", true).put("state", r.out.trim())
            .put("last", prefs.getLong("extra_last_$kind", 0L))
    }

    fun scheduleGet(): JSONObject = JSONObject().put("ok", true)
        .put("on", prefs.getBoolean("maint_on", false))
        .put("lastRun", prefs.getLong("extra_last_bgdexopt", 0L))

    /** Android decides the exact time (needs charging + idle). It is never an exact alarm. */
    fun scheduleSet(on: Boolean): JSONObject {
        val js = ctx.getSystemService(Context.JOB_SCHEDULER_SERVICE) as JobScheduler
        if (!on) {
            js.cancel(JOB_ID); prefs.edit().putBoolean("maint_on", false).apply()
            return JSONObject().put("ok", true).put("msg", "Daily maintenance disabled")
        }
        if (access.mode == Mode.BASIC) return fail("Needs Shizuku or Root")
        val info = JobInfo.Builder(JOB_ID, ComponentName(ctx, MaintenanceJob::class.java))
            .setPeriodic(24 * 3600_000L)
            .setRequiresCharging(true)
            .setRequiresDeviceIdle(true)
            .setPersisted(true)
            .build()
        val ok = js.schedule(info) == JobScheduler.RESULT_SUCCESS
        if (ok) prefs.edit().putBoolean("maint_on", true).apply()
        return if (ok) JSONObject().put("ok", true).put("msg", "Scheduled: about once a day while charging and idle")
        else fail("Android refused to schedule the job")
    }

    // ------------------------------------------------------------------ emergency cooldown
    fun cooldown(steps: List<String>): JSONObject {
        val cr = ctx.contentResolver
        val done = ArrayList<String>()
        val failed = ArrayList<String>()
        val restore = ArrayList<String>()
        val priv = access.mode != Mode.BASIC

        if ("overlay" in steps) { OverlayService.stop(ctx); done.add("overlay stopped") }
        if ("ai" in steps) {
            if (prefs.getBoolean("ai_on", false)) {
                prefs.edit().putBoolean("ai_on", false).putString("ui_profile", "").apply()
                AutoAiService.stop(ctx)
            }
            done.add("optimizer background loop stopped")
        }
        if ("bgkill" in steps) {
            val r = tweaks.cool()
            if (r.errno == 0) done.add("background apps closed") else failed.add("background apps: " + r.err.trim())
        }
        if ("battsaver" in steps) {
            if (!priv) failed.add("battery saver: needs Shizuku/Root")
            else {
                val before = Settings.Global.getInt(cr, "low_power", 0)
                access.execScript("settings put global low_power 1", 15_000)
                val now = Settings.Global.getInt(cr, "low_power", 0)
                if (now == 1) { done.add("battery saver on"); if (before == 0) restore.add("battsaver") }
                else failed.add("battery saver: not applied")
            }
        }
        if ("airplane" in steps) {
            if (!priv) failed.add("airplane mode: needs Shizuku/Root")
            else {
                val before = Settings.Global.getInt(cr, Settings.Global.AIRPLANE_MODE_ON, 0)
                access.execScript("cmd connectivity airplane-mode enable", 15_000)
                try { Thread.sleep(1500) } catch (_: InterruptedException) {}
                val now = Settings.Global.getInt(cr, Settings.Global.AIRPLANE_MODE_ON, 0)
                if (now == 1) { done.add("airplane mode on"); if (before == 0) restore.add("airplane") }
                else failed.add("airplane mode: not applied")
            }
        }
        if (restore.isNotEmpty()) {
            prefs.edit().putString("cd_restore", JSONArray(restore).toString())
                .putLong("cd_restore_at", System.currentTimeMillis() + 10 * 60_000L).apply()
            timer.schedule(Runnable { restore() }, 10, TimeUnit.MINUTES)
        }
        val msg = (if (done.isEmpty()) "Nothing was applied" else "Applied: " + done.joinToString(", ")) +
            (if (failed.isEmpty()) "" else ". Failed: " + failed.joinToString("; "))
        OpLog.add(ctx, "Emergency cooldown - $msg", done.isNotEmpty())
        return JSONObject().put("ok", done.isNotEmpty()).put("msg", msg).put("pending", JSONArray(restore))
    }

    /** The 10-minute timer lives in memory; if Android killed the app meanwhile, airplane mode / battery saver would stay on. */
    fun resumePending() {
        if (cooldownPending().length() == 0) return
        val left = prefs.getLong("cd_restore_at", 0L) - System.currentTimeMillis()
        if (left <= 0) restore() else timer.schedule(Runnable { restore() }, left, TimeUnit.MILLISECONDS)
    }

    fun cooldownPending(): JSONArray = try { JSONArray(prefs.getString("cd_restore", "[]")) } catch (e: Exception) { JSONArray() }

    fun restore(): JSONObject {
        val list = cooldownPending()
        if (list.length() == 0) return JSONObject().put("ok", true).put("msg", "Nothing to restore")
        val undone = ArrayList<String>()
        for (i in 0 until list.length()) {
            when (list.optString(i)) {
                "battsaver" -> { access.execScript("settings put global low_power 0", 15_000); undone.add("battery saver off") }
                "airplane" -> { access.execScript("cmd connectivity airplane-mode disable", 15_000); undone.add("airplane mode off") }
            }
        }
        prefs.edit().remove("cd_restore").remove("cd_restore_at").apply()
        OpLog.add(ctx, "Cooldown restored: " + undone.joinToString(", "))
        return JSONObject().put("ok", true).put("msg", "Restored: " + undone.joinToString(", "))
    }
}
