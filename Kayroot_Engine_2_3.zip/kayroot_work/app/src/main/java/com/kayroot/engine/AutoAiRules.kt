package com.kayroot.engine

import org.json.JSONArray
import org.json.JSONObject
import java.util.Locale

/**
 * Pure decision logic of Auto AI Mode (no Android classes), so it can be unit tested on the JVM.
 * AutoAiService only gathers the inputs (battery, foreground app, clock) and applies the result.
 */

/** IF <metric> <op> <value> THEN <profile>.  metric: "temp" (deg C) or "battery" (%), op: ">" or "<". */
data class CustomRule(val metric: String, val op: String, val value: Double, val profile: String) {
    fun matches(temp: Double, level: Int): Boolean {
        val x = if (metric == "temp") temp else level.toDouble()
        return if (op == ">") x > value else x < value
    }
}

data class AiConfig(
    val nightOn: Boolean = false,
    val nightFrom: Int = 23,          // hour of day, 0..23
    val nightTo: Int = 6,
    val noGameWhileCharging: Boolean = false,
    val lowBattery: Int = 20,
    val minSwitchSec: Int = 60,       // cooldown between two profile switches
    val rules: List<CustomRule> = emptyList()
)

data class AiInput(
    val temp: Double,
    val level: Int,
    val charging: Boolean,
    val isGame: Boolean,
    val hour: Int,
    val hot: Boolean                  // latched thermal state, see nextHot()
)

data class AiDecision(val profile: String, val reason: String)

object AutoAiRules {
    val PROFILES = setOf("game", "daytoday", "powersave")
    const val HOT_ON = 46.0
    const val HOT_OFF = 42.0
    private const val MAX_RULES = 10

    /** Hysteresis: turns on at 46 C, stays on until the battery is back under 42 C. */
    fun nextHot(prev: Boolean, temp: Double): Boolean = if (prev) temp >= HOT_OFF else temp >= HOT_ON

    fun inNight(hour: Int, from: Int, to: Int): Boolean = when {
        from == to -> false
        from < to -> hour in from until to
        else -> hour >= from || hour < to          // e.g. 23 -> 6 wraps past midnight
    }

    fun decide(i: AiInput, c: AiConfig): AiDecision {
        // thermal protection always wins, it can never be overridden by a custom rule
        if (i.hot) return AiDecision("powersave", "High temperature (${f1(i.temp)}°C)")
        for (r in c.rules) {
            if (r.matches(i.temp, i.level)) return AiDecision(r.profile, "Rule: ${r.metric} ${r.op} ${num(r.value)}")
        }
        if (c.nightOn && inNight(i.hour, c.nightFrom, c.nightTo)) return AiDecision("powersave", "Night schedule")
        if (i.isGame && i.level > 10) {
            return if (c.noGameWhileCharging && i.charging) AiDecision("daytoday", "Game detected, but charging")
            else AiDecision("game", "Game detected")
        }
        if (i.level <= c.lowBattery && !i.charging) return AiDecision("powersave", "Low battery (${i.level}%)")
        return AiDecision("daytoday", "Balanced usage")
    }

    /** Cooldown between switches; thermal protection and the very first decision are never delayed. */
    fun canSwitch(now: Long, lastSwitch: Long, minSwitchSec: Int, applied: String, hot: Boolean): Boolean =
        hot || applied.isEmpty() || now - lastSwitch >= minSwitchSec * 1000L

    // ---------------------------------------------------------------- persistence (always sanitised)
    fun fromJson(o: JSONObject?): AiConfig {
        if (o == null) return AiConfig()
        val rules = ArrayList<CustomRule>()
        val arr = o.optJSONArray("rules") ?: JSONArray()
        for (k in 0 until minOf(arr.length(), MAX_RULES)) {
            val r = arr.optJSONObject(k) ?: continue
            val metric = r.optString("metric")
            val op = r.optString("op")
            val profile = r.optString("profile")
            val v = r.optDouble("value", Double.NaN)
            if (metric !in setOf("temp", "battery") || op !in setOf(">", "<") || profile !in PROFILES || v.isNaN()) continue
            val range = if (metric == "temp") 20.0..70.0 else 1.0..100.0
            rules.add(CustomRule(metric, op, v.coerceIn(range.start, range.endInclusive), profile))
        }
        return AiConfig(
            nightOn = o.optBoolean("nightOn", false),
            nightFrom = o.optInt("nightFrom", 23).coerceIn(0, 23),
            nightTo = o.optInt("nightTo", 6).coerceIn(0, 23),
            noGameWhileCharging = o.optBoolean("noGameWhileCharging", false),
            lowBattery = o.optInt("lowBattery", 20).coerceIn(5, 50),
            minSwitchSec = o.optInt("minSwitchSec", 60).coerceIn(0, 600),
            rules = rules
        )
    }

    fun parse(s: String?): AiConfig = try { fromJson(JSONObject(s ?: "{}")) } catch (e: Exception) { AiConfig() }

    fun toJson(c: AiConfig): JSONObject = JSONObject()
        .put("nightOn", c.nightOn).put("nightFrom", c.nightFrom).put("nightTo", c.nightTo)
        .put("noGameWhileCharging", c.noGameWhileCharging).put("lowBattery", c.lowBattery)
        .put("minSwitchSec", c.minSwitchSec)
        .put("rules", JSONArray().also { a ->
            c.rules.forEach { a.put(JSONObject().put("metric", it.metric).put("op", it.op).put("value", it.value).put("profile", it.profile)) }
        })

    private fun f1(v: Double) = String.format(Locale.US, "%.1f", v)
    private fun num(v: Double) = if (v == Math.floor(v)) v.toLong().toString() else f1(v)
}
