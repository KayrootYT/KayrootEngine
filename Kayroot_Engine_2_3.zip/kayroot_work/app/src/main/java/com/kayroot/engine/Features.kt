package com.kayroot.engine

import android.app.ActivityManager
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.hardware.display.DisplayManager
import android.os.BatteryManager
import android.os.Environment
import android.os.StatFs
import android.provider.Settings
import android.view.Display
import org.json.JSONArray
import org.json.JSONObject
import java.util.Locale

data class BatteryInfo(val level: Int, val temp: Double, val voltage: Int, val charging: Boolean)

fun readBattery(ctx: Context): BatteryInfo {
    val i = ctx.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
    val level = i?.getIntExtra(BatteryManager.EXTRA_LEVEL, 0) ?: 0
    val scale = i?.getIntExtra(BatteryManager.EXTRA_SCALE, 100) ?: 100
    val pct = if (scale > 0) level * 100 / scale else level
    val temp = (i?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0) ?: 0) / 10.0
    val volt = i?.getIntExtra(BatteryManager.EXTRA_VOLTAGE, 0) ?: 0
    val st = i?.getIntExtra(BatteryManager.EXTRA_STATUS, -1) ?: -1
    val charging = st == BatteryManager.BATTERY_STATUS_CHARGING || st == BatteryManager.BATTERY_STATUS_FULL
    return BatteryInfo(pct, temp, volt, charging)
}

/** Live stats, system toggles, bypass charging, governor info. */
class Features(private val ctx: Context, private val access: AccessManager, private val tweaks: Tweaks) {

    private val cr get() = ctx.contentResolver

    // ------------------------------------------------------------------ live monitor (no privileges)
    fun stats(): JSONObject {
        val b = readBattery(ctx)
        val mi = ActivityManager.MemoryInfo()
        (ctx.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager).getMemoryInfo(mi)
        val totalMb = mi.totalMem / 1048576
        val usedMb = (mi.totalMem - mi.availMem) / 1048576
        val ramPct = if (totalMb > 0) (usedMb * 100 / totalMb).toInt() else 0
        val sf = StatFs(Environment.getDataDirectory().path)
        val total = sf.blockCountLong * sf.blockSizeLong
        val free = sf.availableBlocksLong * sf.blockSizeLong
        val stoPct = if (total > 0) (((total - free) * 100) / total).toInt() else 0
        return JSONObject()
            .put("battery", JSONObject().put("level", b.level).put("temp", b.temp)
                .put("voltage", b.voltage).put("charging", b.charging))
            .put("ram", JSONObject().put("usedMb", usedMb).put("totalMb", totalMb).put("pct", ramPct))
            .put("storage", JSONObject().put("freeGb", free / 1073741824.0)
                .put("totalGb", total / 1073741824.0).put("pct", stoPct))
    }

    // ------------------------------------------------------------------ toggles: state (read in-process)
    fun toggleGetAll(): JSONObject {
        val o = JSONObject()
        o.put("dnd", JSONObject().put("on", Settings.Global.getInt(cr, "zen_mode", 0) != 0))
        o.put("battery_saver", JSONObject().put("on", Settings.Global.getInt(cr, "low_power", 0) == 1))
        o.put("hi_refresh", JSONObject().put("on", Settings.System.getFloat(cr, "min_refresh_rate", 0f) >= 90f))
        val anim = Settings.Global.getFloat(cr, "window_animation_scale", 1f)
        o.put("fast_anim", JSONObject().put("on", anim in 0.01f..0.6f))
        o.put("stay_awake", JSONObject().put("on", Settings.Global.getInt(cr, "stay_on_while_plugged_in", 0) != 0))
        o.put("bypass", bypassState())
        return o
    }

    // ------------------------------------------------------------------ toggles: set
    fun toggleSet(key: String, on: Boolean): ExecResult {
        if (key == "bypass") return setBypass(on)
        if (access.mode == Mode.BASIC) return ExecResult(2, "", "Enable Shizuku or Root first (HOME > Access Mode)")
        val body = when (key) {
            "dnd" -> if (on) "ok cmd notification set_dnd priority\nok settings put global zen_mode 1"
                     else "ok cmd notification set_dnd off\nok settings put global zen_mode 0"
            "battery_saver" -> "ok settings put global low_power ${if (on) 1 else 0}"
            "hi_refresh" -> if (on) {
                val r = String.format(Locale.US, "%.1f", maxRefreshRate())
                "ok settings put system min_refresh_rate $r\nok settings put system peak_refresh_rate $r"
            } else "ok settings delete system min_refresh_rate\nok settings delete system peak_refresh_rate"
            "fast_anim" -> {
                val s = if (on) "0.5" else "1.0"
                "ok settings put global window_animation_scale $s\nok settings put global transition_animation_scale $s\nok settings put global animator_duration_scale $s"
            }
            "stay_awake" -> "ok settings put global stay_on_while_plugged_in ${if (on) 7 else 0}"
            else -> return ExecResult(127, "", "Unknown control")
        }
        return tweaks.runRaw(body)
    }

    private fun maxRefreshRate(): Float = try {
        val dm = ctx.getSystemService(Context.DISPLAY_SERVICE) as DisplayManager
        dm.getDisplay(Display.DEFAULT_DISPLAY).supportedModes.maxOf { it.refreshRate }
    } catch (e: Exception) { 120f }

    // ------------------------------------------------------------------ bypass charging (root, device specific)
    private data class Node(val path: String, val bypass: String, val normal: String)

    private val nodes = listOf(
        Node("/sys/class/power_supply/battery/input_suspend", "1", "0"),
        Node("/sys/class/qcom-battery/input_suspend", "1", "0"),
        Node("/sys/kernel/debug/google_charger/input_suspend", "1", "0"),
        Node("/sys/devices/platform/google,charger/charge_disable", "1", "0"),
        Node("/sys/class/power_supply/battery/charge_disable", "1", "0"),
        Node("/sys/class/power_supply/battery/batt_slate_mode", "1", "0"),
        Node("/sys/class/power_supply/battery/charging_enabled", "0", "1"),
        Node("/sys/class/power_supply/battery/battery_charging_enabled", "0", "1")
    )

    @Volatile private var bypassCache: Pair<Long, JSONObject>? = null

    private fun bypassState(): JSONObject {
        if (access.mode != Mode.ROOT) return JSONObject().put("on", false).put("supported", true)
        bypassCache?.let { if (System.currentTimeMillis() - it.first < 15_000) return it.second }
        val fresh = probeBypass()
        bypassCache = System.currentTimeMillis() to fresh
        return fresh
    }

    private fun probeBypass(): JSONObject {
        val probe = nodes.joinToString("\n") { "[ -e ${it.path} ] && echo \"${it.path}=$(cat ${it.path} 2>/dev/null)\"" }
        val r = access.execScript(probe, 15_000)
        val found = r.out.lineSequence().filter { it.contains("=") }.associate {
            it.substringBefore("=") to it.substringAfter("=").trim()
        }
        if (found.isEmpty()) return JSONObject().put("on", false).put("supported", false)
        val first = nodes.first { found.containsKey(it.path) }
        return JSONObject().put("on", found[first.path] == first.bypass).put("supported", true)
    }

    private fun setBypass(on: Boolean): ExecResult {
        if (access.mode != Mode.ROOT) return ExecResult(2, "", "Bypass charging needs Root")
        bypassCache = null
        val script = buildString {
            for (n in nodes) {
                val v = if (on) n.bypass else n.normal
                val stop = if (on) "exit 0" else ":"
                appendLine(
                    "if [ -e ${n.path} ]; then chmod +w ${n.path} 2>/dev/null; echo $v > ${n.path} 2>/dev/null; " +
                        "if [ \"$(cat ${n.path} 2>/dev/null)\" = \"$v\" ]; then echo \"ok: via ${n.path}\"; $stop; fi; fi"
                )
            }
        }
        val r = tweaks.runRaw(script)
        return if (r.errno == 0) r else ExecResult(1, r.out, "Bypass charging is not supported on this device/kernel")
    }

    // ------------------------------------------------------------------ CPU governor info (root)
    fun govInfo(): JSONObject {
        if (access.mode != Mode.ROOT) return JSONObject().put("ok", false).put("msg", "Root required")
        val base = "/sys/devices/system/cpu/cpu0/cpufreq"
        val r = access.execScript("echo \"cur=\$(cat $base/scaling_governor 2>/dev/null)\"; echo \"avail=\$(cat $base/scaling_available_governors 2>/dev/null)\"", 15_000)
        val cur = r.out.lineSequence().firstOrNull { it.startsWith("cur=") }?.removePrefix("cur=")?.trim().orEmpty()
        val avail = r.out.lineSequence().firstOrNull { it.startsWith("avail=") }?.removePrefix("avail=")?.trim().orEmpty()
        if (cur.isEmpty()) return JSONObject().put("ok", false).put("msg", "Governor info unavailable")
        val arr = JSONArray()
        avail.split(" ").filter { it.isNotBlank() }.forEach { arr.put(it) }
        return JSONObject().put("ok", true).put("data", JSONObject().put("current", cur).put("available", arr))
    }
}
