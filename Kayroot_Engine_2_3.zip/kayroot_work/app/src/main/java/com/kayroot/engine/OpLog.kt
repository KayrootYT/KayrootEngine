package com.kayroot.engine

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/** Persistent operation history (newest first, max 60 entries). Never stores credentials or personal data. */
object OpLog {
    private const val KEY = "oplog"

    @Synchronized
    fun add(ctx: Context, msg: String, ok: Boolean = true) {
        val p = ctx.getSharedPreferences("kayroot", Context.MODE_PRIVATE)
        val old = try { JSONArray(p.getString(KEY, "[]")) } catch (e: Exception) { JSONArray() }
        val out = JSONArray()
        out.put(JSONObject().put("t", System.currentTimeMillis()).put("m", msg.take(160)).put("ok", ok))
        val n = minOf(old.length(), 59)
        for (i in 0 until n) out.put(old.get(i))
        p.edit().putString(KEY, out.toString()).apply()
    }

    fun list(ctx: Context): JSONArray {
        val p = ctx.getSharedPreferences("kayroot", Context.MODE_PRIVATE)
        return try { JSONArray(p.getString(KEY, "[]")) } catch (e: Exception) { JSONArray() }
    }

    fun clear(ctx: Context) {
        ctx.getSharedPreferences("kayroot", Context.MODE_PRIVATE).edit().remove(KEY).apply()
    }
}
