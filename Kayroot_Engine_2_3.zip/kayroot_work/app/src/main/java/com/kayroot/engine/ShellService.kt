package com.kayroot.engine

import kotlin.system.exitProcess

/**
 * Started by Shizuku as a "user service" -> runs with shell (ADB) privileges, uid 2000.
 * Needs a public no-arg constructor.
 */
class ShellService : IShellService.Stub() {

    override fun destroy() {
        exitProcess(0)
    }

    override fun exec(script: String, timeoutMs: Long): Array<String> =
        Shell.run(arrayOf("sh", "-c", script), timeoutMs)
}
