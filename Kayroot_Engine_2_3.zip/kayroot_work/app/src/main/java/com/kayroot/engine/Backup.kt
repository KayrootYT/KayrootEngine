package com.kayroot.engine

import android.content.SharedPreferences
import org.json.JSONArray
import org.json.JSONObject

/**
 * Export / import of the user's settings as one JSON document.
 * Only an allow-list of keys is ever read or written, and every value is validated on import,
 * so a hand-edited or foreign file cannot inject anything else into the preferences.
 */
object Backup {
    const val FORMAT = "kayroot-backup"
    const val VERSION = 1

    private val PKG = Regex("^[A-Za-z0-9_]+(\\.[A-Za-z0-9_]+)+$")
    private val STR_KEYS = setOf("excl", "ai_games", "ai_cfg", "gov_daytoday", "gov_powersave", "ov_stats")
    private val INT_KEYS = mapOf("ov_alpha" to (20..100), "ov_size" to (9..20), "ov_interval" to (500..10_000))
    private val BOOL_KEYS = setOf("boot_apply", "debug")

    fun export(prefs: SharedPreferences, ui: JSONObject?): JSONObject {
        val p = JSONObject()
        for (k in STR_KEYS) if (prefs.contains(k)) p.put(k, prefs.getString(k, ""))
        for (k in INT_KEYS.keys) if (prefs.contains(k)) p.put(k, prefs.getInt(k, 0))
        for (k in BOOL_KEYS) if (prefs.contains(k)) p.put(k, prefs.getBoolean(k, false))
        return JSONObject().put("format", FORMAT).put("version", VERSION)
            .put("exportedAt", System.currentTimeMillis())
            .put("prefs", p).put("ui", ui ?: JSONObject())
    }

    private fun pkgList(raw: String): String? = try {
        val a = JSONArray(raw)
        val out = JSONArray()
        for (i in 0 until minOf(a.length(), 2000)) { val s = a.optString(i); if (PKG.matches(s)) out.put(s) }
        out.toString()
    } catch (e: Exception) { null }

    private fun sane(key: String, v: String): String? = when (key) {
        "excl", "ai_games" -> pkgList(v)
        "ai_cfg" -> try { AutoAiRules.toJson(AutoAiRules.parse(v)).toString() } catch (e: Exception) { null }
        "gov_daytoday", "gov_powersave" -> v.filter { it.isLetterOrDigit() || it == '_' || it == '-' }.take(40).ifEmpty { null }
        "ov_stats" -> v.filter { it.isLetter() || it == ',' }.take(60)
        else -> null
    }

    /** Returns how many settings were restored, or -1 when the text is not a Kayroot backup. */
    fun import(prefs: SharedPreferences, text: String): Int {
        val root = try { JSONObject(text) } catch (e: Exception) { return -1 }
        if (root.optString("format") != FORMAT || root.optInt("version", 0) !in 1..VERSION) return -1
        val p = root.optJSONObject("prefs") ?: return -1
        val e = prefs.edit()
        var n = 0
        for (k in STR_KEYS) if (p.has(k)) sane(k, p.optString(k))?.let { e.putString(k, it); n++ }
        for ((k, r) in INT_KEYS) if (p.has(k)) { e.putInt(k, p.optInt(k).coerceIn(r.first, r.last)); n++ }
        for (k in BOOL_KEYS) if (p.has(k)) { e.putBoolean(k, p.optBoolean(k)); n++ }
        e.apply()
        return n
    }
}
