package com.kayroot.engine

import android.app.NotificationManager
import android.content.Context
import android.os.Build
import android.os.PowerManager
import android.provider.Settings
import org.json.JSONArray
import org.json.JSONObject

/**
 * Detects what actually works on THIS device. A feature is never shown as working just because its UI exists.
 * Status: supported | partial | permission | shizuku | root | unsupported | failed | untested
 */
class CapabilityManager(private val ctx: Context, private val access: AccessManager) {

    private fun item(id: String, name: String, status: String, detail: String) =
        JSONObject().put("id", id).put("name", name).put("status", status).put("detail", detail)

    fun permissions(): JSONArray {
        val a = JSONArray()
        val pm = ctx.getSystemService(Context.POWER_SERVICE) as PowerManager
        val nm = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        a.put(JSONObject().put("id", "overlay").put("name", "Display over other apps")
            .put("why", "Needed only for the floating stats overlay.").put("ok", Settings.canDrawOverlays(ctx)))
        a.put(JSONObject().put("id", "notif").put("name", "Notifications")
            .put("why", "Shows the status of the Auto AI and overlay services.").put("ok", nm.areNotificationsEnabled()))
        a.put(JSONObject().put("id", "battery").put("name", "Unrestricted battery use")
            .put("why", "Lets Auto AI keep running; some phones kill background services otherwise.")
            .put("ok", pm.isIgnoringBatteryOptimizations(ctx.packageName)))
        a.put(JSONObject().put("id", "shizuku").put("name", "Shizuku")
            .put("why", "Unlocks app disable, dexopt, FPS and CPU stats without root.")
            .put("ok", access.shizukuGranted()))
        a.put(JSONObject().put("id", "root").put("name", "Root")
            .put("why", "Only for governors, bypass charging and kernel tweaks. Checked on request.")
            .put("ok", access.rootOk))
        return a
    }

    fun scan(): JSONArray {
        val probe = ctx.assets.open("scripts/probe_caps.sh").bufferedReader().use { it.readText() }
        val r = access.execScript(probe, 20_000)
        val m = r.out.lineSequence().filter { it.contains("=") }
            .associate { it.substringBefore("=") to it.substringAfter("=").trim() }
        val priv = access.mode != Mode.BASIC
        val root = access.mode == Mode.ROOT
        val a = JSONArray()
        fun yes(k: String) = m[k] == "1"

        a.put(item("cpu_usage", "CPU usage",
            if (yes("procstat")) "supported" else if (!priv) "shizuku" else "unsupported",
            "Android 8+ blocks /proc/stat for normal apps."))
        a.put(item("cpu_freq", "CPU frequency",
            if (yes("cpufreq")) "supported" else if (!priv) "shizuku" else "unsupported", "scaling_cur_freq"))
        a.put(item("gpu", "GPU usage / frequency",
            if (yes("gpu_kgsl")) "supported" else "unsupported",
            if (yes("gpu_kgsl")) "Adreno (kgsl) metrics readable" else "No reliable GPU metric exposed; shown as N/A"))
        a.put(item("thermal", "Temperature & thermal status",
            if (Build.VERSION.SDK_INT >= 29) "supported" else if (yes("thermal")) "partial" else "unsupported",
            "Battery temp always; thermal status needs Android 10+."))
        a.put(item("battery", "Battery info", "supported", "Current/power depend on what the vendor exposes (shown N/A otherwise)."))
        a.put(item("ram", "RAM info", "supported", "ActivityManager + /proc/meminfo"))
        a.put(item("fps", "FPS measurement",
            if (!priv) "shizuku" else if (yes("sf")) "partial" else "unsupported",
            "SurfaceFlinger frame timestamps of the foreground app. Not guaranteed for every game."))
        a.put(item("overlay", "Floating overlay",
            if (Settings.canDrawOverlays(ctx)) "supported" else "permission", "Needs 'Display over other apps'."))
        a.put(item("app_manage", "App list / launch / uninstall", "supported", "Uninstall of user apps goes through Android's own dialog."))
        a.put(item("app_disable", "Disable apps (debloat)",
            if (!priv) "shizuku" else if (yes("pm")) "supported" else "failed", "Reversible. Protected packages are blocked."))
        a.put(item("cache", "Cache cleanup",
            if (priv) "supported" else "partial", if (priv) "pm trim-caches + background kill" else "Own cache + background apps only"))
        a.put(item("dexopt", "ART compile / dexopt",
            if (!priv) "shizuku" else if (yes("dexopt")) "supported" else "unsupported", "cmd package compile / bg-dexopt-job"))
        a.put(item("fstrim", "Filesystem trim",
            if (!priv) "shizuku" else if (root && yes("fstrim")) "supported" else if (yes("smtrim")) "partial" else "unsupported",
            "Root: fstrim. Shizuku: sm fstrim (result is reported as returned)."))
        a.put(item("cooldown", "Emergency cooldown",
            if (priv) "partial" else "shizuku", "Airplane mode / battery saver need Shizuku or Root. Thermal protection is never touched."))
        a.put(item("governor", "CPU governor",
            if (root) "untested" else "root", "Verified only when applied. Shizuku cannot write sysfs."))
        a.put(item("bypass", "Bypass charging",
            if (!root) "root" else if (yes("bypass")) "partial" else "unsupported",
            "Depends on a kernel node; many devices have none."))
        return a
    }
}
