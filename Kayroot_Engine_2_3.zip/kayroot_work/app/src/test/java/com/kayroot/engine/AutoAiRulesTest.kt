package com.kayroot.engine

import org.json.JSONObject
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class AutoAiRulesTest {

    private fun input(
        temp: Double = 33.0, level: Int = 70, charging: Boolean = false,
        game: Boolean = false, hour: Int = 14, hot: Boolean = false
    ) = AiInput(temp, level, charging, game, hour, hot)

    // ---- thermal hysteresis
    @Test fun hot_turns_on_at_46_and_off_below_42() {
        assertFalse(AutoAiRules.nextHot(false, 45.9))
        assertTrue(AutoAiRules.nextHot(false, 46.0))
        assertTrue(AutoAiRules.nextHot(true, 43.0))     // still cooling down
        assertFalse(AutoAiRules.nextHot(true, 41.9))
    }

    // ---- night window
    @Test fun night_window_wraps_past_midnight() {
        assertTrue(AutoAiRules.inNight(23, 23, 6))
        assertTrue(AutoAiRules.inNight(2, 23, 6))
        assertFalse(AutoAiRules.inNight(6, 23, 6))
        assertFalse(AutoAiRules.inNight(12, 23, 6))
    }

    @Test fun night_window_same_day_and_empty() {
        assertTrue(AutoAiRules.inNight(3, 1, 5))
        assertFalse(AutoAiRules.inNight(5, 1, 5))
        assertFalse(AutoAiRules.inNight(3, 5, 5))        // from == to means "never"
    }

    // ---- decisions
    @Test fun default_is_multitasking() {
        assertEquals("daytoday", AutoAiRules.decide(input(), AiConfig()).profile)
    }

    @Test fun game_gets_game_booster() {
        assertEquals("game", AutoAiRules.decide(input(game = true), AiConfig()).profile)
    }

    @Test fun game_on_charger_can_be_blocked() {
        val cfg = AiConfig(noGameWhileCharging = true)
        assertEquals("daytoday", AutoAiRules.decide(input(game = true, charging = true), cfg).profile)
        assertEquals("game", AutoAiRules.decide(input(game = true, charging = false), cfg).profile)
    }

    @Test fun very_low_battery_beats_game() {
        assertEquals("powersave", AutoAiRules.decide(input(game = true, level = 10), AiConfig()).profile)
    }

    @Test fun low_battery_only_when_not_charging() {
        assertEquals("powersave", AutoAiRules.decide(input(level = 20), AiConfig()).profile)
        assertEquals("daytoday", AutoAiRules.decide(input(level = 20, charging = true), AiConfig()).profile)
    }

    @Test fun thermal_protection_always_wins() {
        val cfg = AiConfig(rules = listOf(CustomRule("battery", ">", 10.0, "game")))
        val d = AutoAiRules.decide(input(temp = 47.0, game = true, hot = true), cfg)
        assertEquals("powersave", d.profile)
        assertTrue(d.reason.startsWith("High temperature"))
    }

    @Test fun night_schedule_forces_power_saving() {
        val cfg = AiConfig(nightOn = true, nightFrom = 23, nightTo = 6)
        assertEquals("powersave", AutoAiRules.decide(input(hour = 2, game = true), cfg).profile)
        assertEquals("game", AutoAiRules.decide(input(hour = 15, game = true), cfg).profile)
    }

    @Test fun custom_rule_first_match_wins_over_night_and_game() {
        val cfg = AiConfig(
            nightOn = true,
            rules = listOf(CustomRule("temp", ">", 40.0, "daytoday"), CustomRule("temp", ">", 38.0, "powersave"))
        )
        val d = AutoAiRules.decide(input(temp = 41.0, hour = 2, game = true), cfg)
        assertEquals("daytoday", d.profile)
        assertTrue(d.reason.startsWith("Rule:"))
    }

    @Test fun custom_rule_battery_below() {
        val cfg = AiConfig(rules = listOf(CustomRule("battery", "<", 50.0, "powersave")))
        assertEquals("powersave", AutoAiRules.decide(input(level = 49), cfg).profile)
        assertEquals("daytoday", AutoAiRules.decide(input(level = 50), cfg).profile)
    }

    // ---- cooldown between switches
    @Test fun switch_cooldown() {
        assertTrue(AutoAiRules.canSwitch(1_000, 0, 60, "", false))                 // first decision
        assertFalse(AutoAiRules.canSwitch(30_000, 0, 60, "game", false))           // too soon
        assertTrue(AutoAiRules.canSwitch(61_000, 0, 60, "game", false))
        assertTrue(AutoAiRules.canSwitch(5_000, 0, 60, "game", true))              // thermal is never delayed
        assertTrue(AutoAiRules.canSwitch(1, 0, 0, "game", false))                  // 0 = no delay
    }

    // ---- persistence / sanitising
    @Test fun garbage_json_gives_defaults() {
        assertEquals(AiConfig(), AutoAiRules.parse("not json"))
        assertEquals(AiConfig(), AutoAiRules.parse(null))
    }

    @Test fun invalid_rules_are_dropped_and_values_clamped() {
        val json = JSONObject("""{"lowBattery":99,"minSwitchSec":99999,"nightFrom":77,"rules":[
            {"metric":"temp","op":">","value":999,"profile":"game"},
            {"metric":"cpu","op":">","value":1,"profile":"game"},
            {"metric":"temp","op":"=","value":1,"profile":"game"},
            {"metric":"temp","op":">","value":40,"profile":"rm -rf /"},
            {"metric":"battery","op":"<","profile":"powersave"}]}""")
        val c = AutoAiRules.fromJson(json)
        assertEquals(50, c.lowBattery)
        assertEquals(600, c.minSwitchSec)
        assertEquals(23, c.nightFrom)
        assertEquals(1, c.rules.size)
        assertEquals(70.0, c.rules[0].value, 0.0)
    }

    @Test fun at_most_ten_rules() {
        val arr = (1..15).joinToString(",") { """{"metric":"temp","op":">","value":$it.0,"profile":"powersave"}""" }
        val c = AutoAiRules.fromJson(JSONObject("""{"rules":[$arr]}"""))
        assertEquals(10, c.rules.size)
    }

    @Test fun json_round_trip() {
        val cfg = AiConfig(true, 22, 7, true, 25, 120, listOf(CustomRule("temp", ">", 41.5, "powersave")))
        assertEquals(cfg, AutoAiRules.parse(AutoAiRules.toJson(cfg).toString()))
    }
}
