# Kayroot Engine – Android App (Non-Root + Shizuku + Root)

Magisk module **Kayroot Engine 2.0** ka same UI + animations, ab ek normal APK ke roop me.
WebUI (`app/src/main/assets/webroot`) original hai; backend Kotlin me likha gaya hai.

## APK kaise banaye (GitHub)
1. Naya GitHub repo banao aur is poore folder ka content push karo (`main` branch).
2. **Actions** tab -> *Build APK* khud chalega (ya *Run workflow* dabao).
3. Build khatam hone par run ke **Artifacts** se `KayrootEngine-apk` download karo -> `KayrootEngine-v2.0.apk`.
4. Release banana ho to tag push karo: `git tag v2.0 && git push --tags` (APK Releases me aa jayega).

**Signing (optional but recommended):** Repo Settings -> Secrets me `KEYSTORE_BASE64`, `KEYSTORE_PASSWORD`,
`KEY_ALIAS`, `KEY_PASSWORD` daal do, taaki har update same signature se bane. Secrets na ho to
CI temporary key bana leta hai (APK install hoga, par update ke liye uninstall karna pad sakta hai).

Local build: Android Studio me folder open karo, ya `gradle :app:assembleRelease` (JDK 17, Gradle 8.9).

## Tabs aur features (v2.1)
| Tab | Features |
|---|---|
| HOME | Access Mode (Basic / Shizuku / Root), Profile Manager: **Auto AI Mode**, Game Booster, Multitasking, Power Saving, Reset |
| QUICK | **Live Monitor** (battery, RAM, storage, temp), Cleaner, Cooling, Optimizer, **Net Refresh**, Activity Log |
| ADVANCE | **Do Not Disturb**, **Bypass Charging** (Root), Battery Saver, Max Refresh Rate, Fast Animations, Stay Awake while charging, **CPU Governor** chooser (Root), terminal log |
| ABOUT | Accent **themes**, matrix rain on/off, haptics, re-apply on boot, Shizuku guide, Support/Telegram |

**Auto AI Mode:** foreground service jo har 6 sec battery temp, charge level aur foreground app dekhta hai:
game open -> Game Booster, temp >= 46C ya battery <= 20% (not charging) -> Power Saving, baaki -> Multitasking.
Shizuku ya Root zaroori hai.


## v2.2 - tabs (5)
Bottom nav: **HOME, APPS, QUICK, ADVANCED, SETTINGS**. Live Monitor, Battery aur FPS overlay ab ADVANCED me hain.

| Tab | Kya hai |
|---|---|
| HOME | Access Mode, profiles (Auto AI, Game Booster, Multitasking, Power Saving), Recent operations |
| APPS | MANAGE (search, filter, details, launch, uninstall, disable/enable, cleaner exclusion) + DEBLOAT (preview, confirm, re-enable) |
| QUICK | Cleaner, Cooling, Optimizer, Net Refresh, Dexopt/Recompile/Trim, Cooldown, logs, daily maintenance, Activity log (sab items ek jaise menu cards) |
| ADVANCED | Live Monitor, Processor/Memory/Thermal/Battery details, FPS overlay, system controls, CPU governor, event console |
| SETTINGS | Theme/haptic/boot, permissions, capability scan, debug, Shizuku guide, About |


## v2.3
Light/dark/auto mode, bundled font (offline), pull-to-refresh, skeleton loaders, accessibility labels, tablet layout, first-run intro,
Auto AI custom rules + night schedule + game list, settings backup/restore, local crash log, root re-check, hardened JS bridge.
Details: `CHANGELOG_KAYROOT_v2_3.txt`. CI now runs `gradle :app:testDebugUnitTest` before building.
